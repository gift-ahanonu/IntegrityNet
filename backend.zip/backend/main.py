from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from routes import users, scams, chatbot  
import joblib
from fastapi.middleware.cors import CORSMiddleware
from slowapi.errors import RateLimitExceeded
from fastapi.responses import JSONResponse
from config import limiter  
from fastapi.staticfiles import StaticFiles
import os

app = FastAPI()
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, lambda request, exc: JSONResponse(
    status_code=429,
    content={"detail": "Too many requests. Please slow down."}
))

app.mount("/static", StaticFiles(directory="static"), name="static")
app.include_router(users.router, prefix="/users", tags=["Users"])
app.include_router(scams.router, prefix="/scams", tags=["Scams"])
app.include_router(chatbot.router, prefix="/chatbot", tags=["Chatbot"])

uploads_path = os.path.join(os.getcwd(), "uploads")
app.mount("/uploads", StaticFiles(directory=uploads_path), name="uploads")

# Allow CORS 
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173",
    "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/", response_class=HTMLResponse)
def home():
    return "<h1>Welcome to IntegrityNet API</h1><p>Go to <a href='/docs'>/docs</a> for API documentation.</p>"

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)