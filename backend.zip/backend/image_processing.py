import numpy as np
import cv2
import pytesseract
import exifread
import re
from pyzbar.pyzbar import decode
from PIL import Image
import requests
import os

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"


def extract_qr_code(image_path):
    """Detects and extracts QR code contents from an image & checks for scam indicators."""
    image = cv2.imread(image_path)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    qr_codes = decode(gray)

    extracted_data = []
    for qr in qr_codes:
        qr_text = qr.data.decode("utf-8")
        extracted_data.append(qr_text)

    return extracted_data if extracted_data else None

def extract_urls_from_text(text):
    """Extracts all possible URLs from a given text, including ones without 'https://'."""
    url_pattern = r"(https?://[^\s]+|www\.[^\s]+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})"
    urls = re.findall(url_pattern, text)
    return urls if urls else None

def analyze_image_text(image_path):
    """Extract text from an image using OCR & extract URLs from the text."""
    print(f" Processing image: {image_path}")

    try:
        image = cv2.imread(image_path)
        if image is None:
            print(" Error: Image not loaded properly!")
            return "Error: Image could not be loaded."

        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        extracted_text = pytesseract.image_to_string(gray)

        print(f"Extracted Text: {extracted_text[:500]}")  # Print first 500 chars 

        # Extract URLs from the extracted text
        extracted_urls = extract_urls_from_text(extracted_text)

        return extracted_text, extracted_urls
    except Exception as e:
        print(f" OCR Error: {e}")
        return f"Error: {e}", None

def detect_forgery(image_path):
    """Placeholder function for image forgery detection."""
    print(f" Checking image forgery: {image_path}")
    return False  

def extract_exif_metadata(image_path: str):
    with open(image_path, 'rb') as img_file:
        tags = exifread.process_file(img_file)
    return {tag: str(tags[tag]) for tag in tags if tag.startswith("Image")}
