from sqlalchemy import Column, String, Integer, DateTime, Boolean, Text, func, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from uuid import uuid4
from datetime import datetime
from database import Base


Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False) 
    hashed_password = Column(String)
    role = Column(String, default="user")
    created_at = Column(DateTime, default=datetime.utcnow)
    chat_messages = relationship("ChatMessage", back_populates="user")
    profile_picture = Column(String, nullable=True) 

class ScanResult(Base):
    __tablename__ = "scan_results"
    id = Column(Integer, primary_key=True, index=True)
    scan_type = Column(String)
    scan_content = Column(String)
    scam_detected = Column(Boolean)
    timestamp = Column(DateTime, default=datetime.utcnow)

class ScamLog(Base):
    __tablename__ = "scam_logs"

    id = Column(Integer, primary_key=True, index=True)
    content = Column(Text, nullable=False)  
    scam_detected = Column(Boolean, nullable=False)
    confidence = Column(String, nullable=False)
    explanation = Column(Text, nullable=False)
    scan_type = Column(String, nullable=False)  
    timestamp = Column(DateTime, server_default=func.now())  

class ReportedScam(Base):
    __tablename__ = "reported_scams"

    id = Column(Integer, primary_key=True, index=True)
    scam_type = Column(String, nullable=False)  
    content = Column(Text, nullable=False)  
    description = Column(Text, nullable=True)  
    reported_by = Column(String, nullable=False)  
    is_reviewed = Column(Boolean, default=False)  
    is_verified = Column(Boolean, default=False)  
    timestamp = Column(DateTime, default=func.now())  
    image_path = Column(String, nullable=True)  


class ChatMessage(Base):
    __tablename__ = "chat_messages"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)  
    session_id = Column(String, index=True, default=lambda: str(uuid4()))
    message = Column(Text, nullable=False)
    response = Column(Text, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)
    title = Column(String, nullable=True)
    user = relationship("User")
    