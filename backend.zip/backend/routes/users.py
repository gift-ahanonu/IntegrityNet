from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, Request, File, UploadFile
from sqlalchemy.orm import Session
from database import get_db
from auth import create_access_token, authenticate_user, get_password_hash, verify_password, get_current_user, get_current_admin, fm
from models import User
from pydantic import BaseModel, EmailStr
import re
from auth import PasswordResetRequest, PasswordResetConfirm, serializer, send_reset_email
from fastapi.security import OAuth2PasswordRequestForm
from fastapi_mail import FastMail, MessageSchema
from config import limiter 
import itsdangerous
import shutil
import os

router = APIRouter()

class UserCreate(BaseModel):
    username: str
    email: EmailStr
    password: str
    confirm_password: str

class UserLogin(BaseModel):
    username: str
    password: str

class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str
    confirm_new_password: str

class ChangeEmailRequest(BaseModel):
    new_email: EmailStr
    confirm_email: EmailStr

class ChangeUsernameRequest(BaseModel):
    new_username: str


# Password strength validation function
def validate_password_strength(password: str):
    """Ensure password meets security standards."""
    if len(password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters long.")

    if not any(char.isupper() for char in password):
        raise HTTPException(status_code=400, detail="Password must contain at least one uppercase letter.")

    if not any(char.islower() for char in password):
        raise HTTPException(status_code=400, detail="Password must contain at least one lowercase letter.")

    if not any(char.isdigit() for char in password):
        raise HTTPException(status_code=400, detail="Password must contain at least one number.")

    if not re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
        raise HTTPException(status_code=400, detail="Password must contain at least one special character.")



@router.post("/register")
def register_user(user: UserCreate, db: Session = Depends(get_db)):

    validate_password_strength(user.password)

    # Check if passwords match
    if user.password != user.confirm_password:
        raise HTTPException(status_code=400, detail="Passwords do not match")

    # Check if username or email already exists
    existing_user = db.query(User).filter((User.username == user.username) | (User.email == user.email)).first()
    if existing_user:
        raise HTTPException(status_code=400, detail="Username or email already registered")

    # Hash the password
    hashed_password = get_password_hash(user.password)

    # Create new user
    new_user = User(username=user.username, email=user.email, hashed_password=hashed_password)
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    return {"message": "User registered successfully", "username": new_user.username, "email": new_user.email}


@router.post("/token")
@limiter.limit("5/minute")
async def login_for_access_token(
    request: Request, 
    db: Session = Depends(get_db), 
    form_data: OAuth2PasswordRequestForm = Depends()
):
    db_user = db.query(User).filter(User.username == form_data.username).first()
    if not db_user or not verify_password(form_data.password, db_user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    access_token = create_access_token({"sub": str(db_user.id), "role": db_user.role})
    return {"access_token": access_token, "token_type": "bearer"}


@router.post("/reset-password-request")
def reset_password_request(request: PasswordResetRequest, db: Session = Depends(get_db), background_tasks: BackgroundTasks = BackgroundTasks()):
    """Generates a password reset token and sends a reset email."""
    user = db.query(User).filter(User.email == request.email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User with this email not found")

    # Generate reset token
    token = serializer.dumps(request.email, salt="password-reset-salt")

    # Send email in the background
    background_tasks.add_task(send_reset_email, request.email, token)

    return {"message": "Password reset email sent successfully."}


@router.post("/reset-password")
def reset_password(request: PasswordResetConfirm, db: Session = Depends(get_db)):
    """Verifies the token and allows password reset."""
    try:
        email = serializer.loads(request.token, salt="password-reset-salt", max_age=3600)
    except itsdangerous.exc.SignatureExpired:
        raise HTTPException(status_code=400, detail="Reset token has expired")
    except itsdangerous.exc.BadSignature:
        raise HTTPException(status_code=400, detail="Invalid reset token")

    user = db.query(User).filter(User.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    validate_password_strength(request.new_password) 

    user.hashed_password = get_password_hash(request.new_password)
    db.commit()

    return {"message": "Password has been reset successfully."}

async def send_password_change_email(user_email: str, username: str):
    """
    Sends an email notification when a user changes their password.
    """
    subject = "🔐 Password Change Confirmation"
    body = f"""
    Hello {username},

    Your password was successfully changed.

    If you made this change, no further action is required.
    If you did not request this change, please contact support immediately.

    - The IntegrityNet Team
    """

    message = MessageSchema(
        subject=subject,
        recipients=[user_email],
        body=body,
        subtype="plain"
    )

    await fm.send_message(message)  # Send email 

@router.put("/change-password")
async def change_password(
    request: ChangePasswordRequest,
    background_tasks: BackgroundTasks,  # Run email in the background
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Allows a logged-in user to change their password.
    Sends a confirmation email after a successful change.
    """
    # Fetch user from database
    user = db.query(User).filter(User.id == current_user.id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Verify current password
    if not verify_password(request.current_password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Incorrect current password")

    # Check if new passwords match
    if request.new_password != request.confirm_new_password:
        raise HTTPException(status_code=400, detail="New passwords do not match")

    # Enforce password strength
    if len(request.new_password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters long")
    if not any(char.isupper() for char in request.new_password):
        raise HTTPException(status_code=400, detail="Password must contain at least one uppercase letter")
    if not any(char.islower() for char in request.new_password):
        raise HTTPException(status_code=400, detail="Password must contain at least one lowercase letter")
    if not any(char.isdigit() for char in request.new_password):
        raise HTTPException(status_code=400, detail="Password must contain at least one number")
    if not any(char in "!@#$%^&*()-_=+[]{}|;:'\",.<>?/" for char in request.new_password):
        raise HTTPException(status_code=400, detail="Password must contain at least one special character")

    # Hash and update new password
    user.hashed_password = get_password_hash(request.new_password)
    db.commit()

    # Send password change confirmation email
    background_tasks.add_task(send_password_change_email, user.email, user.username)

    return {"message": "Password changed successfully. A confirmation email has been sent."}

async def send_email_change_confirmation(user_email: str, username: str):
    """
    Sends a confirmation email after an email change.
    """
    subject = " Email Change Confirmation"
    body = f"""
    Hello {username},

    Your email has been successfully changed.

    If you made this change, no further action is required.
    If you did not request this change, please contact support immediately.

    - The IntegrityNet Team
    """

    message = MessageSchema(
        subject=subject,
        recipients=[user_email],
        body=body,
        subtype="plain"
    )

    await fm.send_message(message)

@router.put("/change-email")
async def change_email(
    request: ChangeEmailRequest,
    background_tasks: BackgroundTasks,  
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Allows a logged-in user to change their email.
    Sends a confirmation email after a successful change.
    """
    # Validate email match
    if request.new_email != request.confirm_email:
        raise HTTPException(status_code=400, detail="Emails do not match")

    # Check if the email is already taken
    existing_email = db.query(User).filter(User.email == request.new_email).first()
    if existing_email:
        raise HTTPException(status_code=400, detail="Email is already in use")

    # Update user email
    current_user.email = request.new_email
    db.commit()

    # Send confirmation email
    background_tasks.add_task(send_email_change_confirmation, request.new_email, current_user.username)

    return {"message": "Email changed successfully. A confirmation email has been sent."}


@router.put("/change-username")
def change_username(
    request: ChangeUsernameRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Allows a logged-in user to change their username.
    """
    # Check if username is already taken
    existing_username = db.query(User).filter(User.username == request.new_username).first()
    if existing_username:
        raise HTTPException(status_code=400, detail="Username is already taken")

    # Update username
    current_user.username = request.new_username
    db.commit()

    return {"message": "Username changed successfully."}

@router.post("/upload-picture")
def upload_picture(file: UploadFile = File(...), db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    filename = f"user_{current_user.id}_{file.filename}"
    file_location = f"static/profile_pics/{filename}"

    os.makedirs("static/profile_pics", exist_ok=True)
    with open(file_location, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    current_user.profile_picture = filename
    db.commit()
    return {"filename": filename}

@router.put("/remove-picture")
def remove_profile_picture(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    current_user.profile_picture = "default.png"
    db.commit()
    return {"message": "Profile picture removed"}


@router.delete("/delete-account")
def delete_account(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    db.delete(current_user)
    db.commit()
    return {"message": "Account deleted successfully"}

@router.get("/me")
def get_current_user_data(current_user: User = Depends(get_current_user)):
    return {
        "username": current_user.username,
        "email": current_user.email,
        "profile_picture": current_user.profile_picture,
        "role": current_user.role
    }
@router.get("/admin/users")
def get_all_users(db: Session = Depends(get_db), admin_user: dict = Depends(get_current_admin)):
    users = db.query(User).all()
    return [
        {
            "id": u.id,
            "username": u.username,
            "email": u.email,
            "role": u.role or "user"
        } for u in users
    ]

@router.delete("/admin/users/{user_id}")
def delete_user(user_id: int, db: Session = Depends(get_db), admin_user: dict = Depends(get_current_admin)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    db.delete(user)
    db.commit()
    return {"message": f"User {user.username} deleted successfully"}

from pydantic import BaseModel

class AdminToggleRequest(BaseModel):
    make_admin: bool

@router.put("/admin/users/{user_id}/set-admin")
def toggle_admin_role(user_id: int, request: AdminToggleRequest, db: Session = Depends(get_db), admin_user: dict = Depends(get_current_admin)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.role = "admin" if request.make_admin else None
    db.commit()
    return {"message": f"User {user.username} updated to {'admin' if request.make_admin else 'regular user'}"}