from fastapi import APIRouter, UploadFile, File, Form, Depends, HTTPException, BackgroundTasks, Query, Request  
from image_processing import analyze_image_text, extract_qr_code
import shutil
import os
from scam_detection import analyze_text_with_gpt4, analyze_url_with_gpt4
from pydantic import BaseModel, validator
from sqlalchemy.orm import Session
from database import get_db
from models import ScamLog, ReportedScam, User
import re
from typing import Optional
from auth import get_current_user, get_current_admin, fm  
from fastapi_mail import FastMail, MessageSchema
from typing import Optional
import asyncio
from sqlalchemy.sql import func 
from config import limiter

router = APIRouter()
UPLOAD_FOLDER = "uploads"
ADMIN_EMAIL = "integritynet.team@gmail.com"
  

class TextRequest(BaseModel):
    content: str  

class URLRequest(BaseModel):
    content: str  

class ScamReport(BaseModel):
    scam_type: str 
    content: str  
    description: Optional[str] = None 
    reported_by: str 

    @validator("scam_type")
    def validate_scam_type(cls, value):
        allowed_types = {"text", "url", "image"}
        if value not in allowed_types:
            raise ValueError(f"Invalid scam_type. Allowed values: {allowed_types}")
        return value

class ScamReviewRequest(BaseModel):
    is_reviewed: bool
    is_verified: bool

async def send_admin_notification(scam_id: int, scam_type: str, reported_by: str):
    """Send an email to the admin when a new scam is reported."""
    scam_link = f"http://127.0.0.1:8000/scams/review/{scam_id}"  

    message = MessageSchema(
        subject="🚨 New Scam Report Alert!",
        recipients=[ADMIN_EMAIL],
        body=f"""
        A new scam has been reported!

        Scam ID: {scam_id}
        Type: {scam_type}
        Reported By: {reported_by}

        Click below to review:
        {scam_link}

        - IntegrityNet Team
        """,
        subtype="plain",
    )

    await fm.send_message(message)

def extract_urls_from_text(text):
    """Extracts all possible URLs from a given text, including ones without 'https://'."""
    url_pattern = r"(https?://[^\s]+|www\.[^\s]+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})"
    urls = re.findall(url_pattern, text)
    return urls if urls else None

@router.post("/analyze_text")
def analyze_text(request: TextRequest, db: Session = Depends(get_db)):
    """Analyzes text using GPT-4o with confidence-based feedback and logs results."""
    analysis = analyze_text_with_gpt4(request.content)

    if " - " in analysis:
        confidence, explanation = analysis.split(" - ", 1)
        confidence = confidence.strip().replace("\"", "")
    else:
        confidence = "Error"
        explanation = analysis

    scam_detected = confidence.lower() in ["yes", "very likely"]

    scam_entry = ScamLog(
        content=request.content,
        scam_detected=scam_detected,
        confidence=confidence,
        explanation=explanation,
        scan_type="text"
    )
    db.add(scam_entry)
    db.commit()

    return {
        "scam_detected": scam_detected,
        "confidence": confidence,
        "explanation": explanation
    }

@router.post("/analyze_url")
def analyze_url(request: URLRequest, db: Session = Depends(get_db)):
    """Analyzes a URL using GPT-4o with confidence-based feedback and logs results."""
    analysis = analyze_url_with_gpt4(request.content)

    if " - " in analysis:
        confidence, explanation = analysis.split(" - ", 1)
        confidence = confidence.strip().replace("\"", "")
    else:
        confidence = "Error"
        explanation = analysis

    scam_detected = confidence.lower() in ["yes", "very likely"]

    scam_entry = ScamLog(
        content=request.content,
        scam_detected=scam_detected,
        confidence=confidence,
        explanation=explanation,
        scan_type="url"
    )
    db.add(scam_entry)
    db.commit()

    return {
        "scam_detected": scam_detected,
        "confidence": confidence,
        "explanation": explanation
    }

@router.post("/upload_screenshot")
async def upload_screenshot(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """Extracts text & QR codes from an image, detects all URLs, and checks for scams."""
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    file_path = f"{UPLOAD_FOLDER}/{file.filename}"
    
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    # Extract text from the image
    extracted_text_result = analyze_image_text(file_path)

    extracted_text = extracted_text_result[0] if isinstance(extracted_text_result, tuple) else extracted_text_result

    text_analysis = analyze_text_with_gpt4(extracted_text)

    # Extract URLs from the extracted text
    extracted_urls = extract_urls_from_text(extracted_text)
    url_analysis_results = []
    url_scam_detected = False

    if extracted_urls:
        for url in extracted_urls:
            url_analysis = analyze_url_with_gpt4(url)
            url_confidence, url_explanation = (
                url_analysis.split(" - ", 1) if " - " in url_analysis else ("Error", url_analysis)
            )
            url_confidence = url_confidence.strip().replace("\"", "")

            if url_confidence.lower() in ["yes", "very likely"]:
                url_scam_detected = True

            url_analysis_results.append({
                "url": url,
                "confidence": url_confidence,
                "explanation": url_explanation
            })

    # Extract and analyse QR code
    qr_data = extract_qr_code(file_path)
    qr_scam_detected = False
    qr_url = "None"
    qr_confidence = "No QR found"
    qr_explanation = ""

    if qr_data:
        qr_url = qr_data[0]  # Get the first QR code found
        qr_analysis = analyze_url_with_gpt4(qr_url)
        qr_confidence, qr_explanation = (
            qr_analysis.split(" - ", 1) if " - " in qr_analysis else ("Error", qr_analysis)
        )
        qr_confidence = qr_confidence.strip().replace("\"", "")

        qr_scam_detected = qr_confidence.lower() in ["yes", "very likely"]

    # Extract confidence and explanation from text analysis
    text_confidence, text_explanation = (
        text_analysis.split(" - ", 1) if " - " in text_analysis else ("Error", "No explanation provided.")
    )
    text_confidence = text_confidence.strip().replace("\"", "")

    # Final scam detection decision
    scam_detected = text_confidence.lower() in ["yes", "very likely"] or qr_scam_detected or url_scam_detected

    scam_entry = ScamLog(
        content=extracted_text,
        scam_detected=scam_detected,
        confidence=text_confidence,
        explanation=text_explanation,
        scan_type="image"
    )
    db.add(scam_entry)
    db.commit()

    return {
        "scam_detected": scam_detected,
        "confidence": text_confidence,
        "extracted_text": extracted_text,
        "text_explanation": text_explanation,
        "qr_code_detected": qr_data is not None,
        "qr_code_content": qr_url,
        "qr_confidence": qr_confidence,
        "qr_explanation": qr_explanation,
        "extracted_urls": url_analysis_results
    }

@router.post("/report_scam")
@limiter.limit("3/minute")
async def report_scam(
    request: Request,
    background_tasks: BackgroundTasks,
    scam_type: str = Form(...),
    content: str = Form(...),
    reported_by: str = Form(...),
    description: Optional[str] = Form(None),
    image: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db)
):
    """
    Users can report scams by submitting text, URLs, or images.
    An image upload is optional.
    """

    allowed_scam_types = {"text", "url", "image"}
    if scam_type not in allowed_scam_types:
        raise HTTPException(status_code=400, detail=f"Invalid scam_type. Allowed values: {allowed_scam_types}")

    image_path = None  # Default if no image is uploaded

    # Handle image upload if provided
    if image:
        os.makedirs(UPLOAD_FOLDER, exist_ok=True)  # Ensure folder exists
        image_path = os.path.join(UPLOAD_FOLDER, image.filename)

        with open(image_path, "wb") as buffer:
            shutil.copyfileobj(image.file, buffer)

    scam_report = ReportedScam(
        scam_type=scam_type,
        content=content,
        description=description,
        reported_by=reported_by,
        image_path=image_path
    )
    db.add(scam_report)
    db.commit()
    db.refresh(scam_report)

    # Send Email Notification to Admin
    scam_details = f"""
    🚨 New Scam Report Submitted 🚨
    
    - Scam Type: {scam_type}
    - Reported By: {reported_by}
    - Description: {description if description else 'No description provided'}
    - Content: {content}
    - Image Uploaded: {'Yes' if image else 'No'}

    Click here to review: http://localhost:5173/admin/scams
    """

    message = MessageSchema(
        subject="🚨 New Scam Report Alert!",
        recipients=[ADMIN_EMAIL],
        body=scam_details,
        subtype="plain"
    )

    background_tasks.add_task(fm.send_message, message)

    return {
        "message": "Scam report submitted successfully!",
        "scam_type": scam_type,
        "content": content,
        "description": description,
        "reported_by": reported_by,
        "image_uploaded": bool(image),
    }

@router.get("/my_reports")
def get_my_reports(
    status: Optional[str] = Query(None, enum=["pending", "reviewed", "verified"]),  #  Filtering by status
    sort_by: Optional[str] = Query("newest", enum=["newest", "oldest"]),  #  Sorting
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)  
):
    """
    Fetch all scam reports submitted by the logged-in user.
    Users can filter by status and sort by newest/oldest.
    """

    #  Filter reports by logged-in user
    query = db.query(ReportedScam).filter(ReportedScam.reported_by == current_user.username)

    #  Apply status filters if provided
    if status == "pending":
        query = query.filter(ReportedScam.is_reviewed == False)
    elif status == "reviewed":
        query = query.filter(ReportedScam.is_reviewed == True)
    elif status == "verified":
        query = query.filter(ReportedScam.is_verified == True)

    #  Apply sorting
    if sort_by == "newest":
        query = query.order_by(ReportedScam.timestamp.desc())
    else:
        query = query.order_by(ReportedScam.timestamp.asc())

    user_reports = query.all()

    #  Return a response even if no reports are found
    if not user_reports:
        return {"message": "No scam reports found for this user."}

    return [
        {
            "id": report.id,
            "scam_type": report.scam_type,
            "content": report.content,
            "description": report.description,
            "reported_by": report.reported_by,
            "timestamp": report.timestamp,
            "is_reviewed": report.is_reviewed,
            "is_verified": report.is_verified
        }
        for report in user_reports
    ]
@router.get("/user_stats")
def get_user_stats(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Return scam report stats for the currently logged-in user.
    """
    total = db.query(ReportedScam).filter_by(reported_by=current_user.username).count()
    verified = db.query(ReportedScam).filter_by(reported_by=current_user.username, is_verified=True).count()
    reviewed = db.query(ReportedScam).filter_by(reported_by=current_user.username, is_reviewed=True, is_verified=False).count()
    pending = total - (verified + reviewed)

    return {
        "total": total,
        "verified": verified,
        "reviewed": reviewed,
        "pending": pending
    }


@router.get("/reported_scams")
def get_reported_scams(
    db: Session = Depends(get_db),
    admin_user: dict = Depends(get_current_admin) 
):
    """Retrieve all reported scams - Admin only"""
    scams = db.query(ReportedScam).all()
    return scams


@router.put("/review/{scam_id}")
def review_scam(
    scam_id: int,
    is_verified: bool,
    db: Session = Depends(get_db),
    admin_user: dict = Depends(get_current_admin),
    background_tasks: BackgroundTasks = BackgroundTasks()
):
    """
    Admins review a reported scam and mark it as verified or not.
    """
    scam_report = db.query(ReportedScam).filter(ReportedScam.id == scam_id).first()
    if not scam_report:
        raise HTTPException(status_code=404, detail="Scam report not found")

    # Update scam report status
    scam_report.is_reviewed = True
    scam_report.is_verified = is_verified
    db.commit()

    # Send email notification 
    background_tasks.add_task(send_review_notification, db, scam_report.reported_by, scam_report)

    return {"message": "Scam report reviewed successfully.", "scam_id": scam_id, "is_verified": is_verified}


async def send_review_notification(db: Session, reported_by: str, scam_report: ReportedScam):
    """
    Sends an email notification to the user after their scam report is reviewed.
    """
    # Retrieve the user's email from the database
    user = db.query(User).filter(User.username == reported_by).first()
    if not user or not user.email:
        print(" No valid email found for user:", reported_by)
        return  # Exit if no valid email is found

    user_email = user.email  # Get the user's email instead of the username

    subject = "Your Scam Report Has Been Reviewed ✅"
    status_text = "verified as a scam" if scam_report.is_verified else "not verified as a scam"

    body = f"""
    Hello,

    Your scam report (ID: {scam_report.id}) has been reviewed by the IntegrityNet team.

    - Scam Type: {scam_report.scam_type}
    - Content: {scam_report.content}
    - Status: {status_text}

    You can check the status of your reports in your dashboard.

    Thank you for keeping the internet safe!

    - The IntegrityNet Team
    """

    message = MessageSchema(
        subject=subject,
        recipients=[user_email],  
        body=body,
        subtype="plain"
    )

    await fm.send_message(message)  # Send the email

@router.get("/verified")
def get_verified_scams(
    db: Session = Depends(get_db),
    admin_user: dict = Depends(get_current_admin)  # Admin only
):
    """Retrieve only verified scam reports - Admin only"""
    scams = db.query(ReportedScam).filter(ReportedScam.is_verified == True).all()
    return scams

@router.get("/stats")
def get_scam_statistics(db: Session = Depends(get_db), current_user: User = Depends(get_current_admin)):
    """
    Get scam statistics (admin-only).
    """

    total_reports = db.query(ReportedScam).count()
    reviewed_reports = db.query(ReportedScam).filter(ReportedScam.is_reviewed == True).count()
    pending_reports = total_reports - reviewed_reports
    verified_scams = db.query(ReportedScam).filter(ReportedScam.is_verified == True).count()

    # Scam Type Breakdown
    scam_types = db.query(ReportedScam.scam_type, func.count(ReportedScam.id)).group_by(ReportedScam.scam_type).all()
    scam_types_dict = {scam_type: count for scam_type, count in scam_types}

    return {
        "total_reports": total_reports,
        "reviewed_reports": reviewed_reports,
        "pending_reports": pending_reports,
        "verified_scams": verified_scams,
        "scam_type_breakdown": scam_types_dict
    }

@router.get("/trends", dependencies=[Depends(get_current_admin)])
def get_scam_trends(db: Session = Depends(get_db)):
    """
    Provides insights into scam trends over time (admin-only).
    """

    from datetime import datetime, timedelta

    # Define time ranges
    last_7_days = datetime.utcnow() - timedelta(days=7)
    last_30_days = datetime.utcnow() - timedelta(days=30)

    # Get reports for last 7 & 30 days
    reports_last_7_days = (
        db.query(func.date_trunc('day', ReportedScam.timestamp), func.count(ReportedScam.id))
        .filter(ReportedScam.timestamp >= last_7_days)
        .group_by(func.date_trunc('day', ReportedScam.timestamp))
        .all()
    )

    reports_last_30_days = (
        db.query(func.date_trunc('day', ReportedScam.timestamp), func.count(ReportedScam.id))
        .filter(ReportedScam.timestamp >= last_30_days)
        .group_by(func.date_trunc('day', ReportedScam.timestamp))
        .all()
    )

    # Scam Types in the Last 30 Days
    scam_type_trends = (
        db.query(ReportedScam.scam_type, func.count(ReportedScam.id))
        .filter(ReportedScam.timestamp >= last_30_days)
        .group_by(ReportedScam.scam_type)
        .all()
    )

    return {
        "reports_last_7_days": {str(date): count for date, count in reports_last_7_days},
        "reports_last_30_days": {str(date): count for date, count in reports_last_30_days},
        "scam_type_trends": {scam: count for scam, count in scam_type_trends}
    }

@router.delete("/{scam_id}")
def delete_scam_report(
    scam_id: int,
    db: Session = Depends(get_db),
    admin_user: User = Depends(get_current_admin)
):
    scam = db.query(ReportedScam).filter(ReportedScam.id == scam_id).first()
    if not scam:
        raise HTTPException(status_code=404, detail="Scam report not found")

    db.delete(scam)
    db.commit()
    return {"message": "Scam deleted successfully"}
