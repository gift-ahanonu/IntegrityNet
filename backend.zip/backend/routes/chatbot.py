from fastapi import APIRouter, Depends, HTTPException, Request, Body
from sqlalchemy.orm import Session, joinedload
from sqlalchemy.sql import func
from openai import OpenAIError
from database import get_db
from auth import get_current_user, get_current_admin, get_optional_user
from models import ChatMessage, User
from pydantic import BaseModel
from uuid import uuid4
import openai
import os
import re
from config import limiter
from typing import Optional

router = APIRouter()
openai.api_key = os.getenv("OPENAI_API_KEY")

class ChatRequest(BaseModel):
    message: str
    session_id: str = None

class RenameRequest(BaseModel):
    new_title: str

@router.post("/chatbot")
@limiter.limit("10/minute")
def chatbot_chat(
    request: Request,
    chat: ChatRequest,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_optional_user)
):
    session_id = chat.session_id or str(uuid4())
    is_new_session = not chat.session_id

    print("👤 current_user is:", current_user)
    print(f"Saving chat for user_id = {current_user.id if current_user else 'GUEST'}")

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {
                    "role": "system",
                    "content": (
                        """
You are IntegrityBot, an assistant for the IntegrityNet web application.

You must only answer questions related to how the IntegrityNet app works. Decline anything unrelated.

IntegrityNet Features:
- Scam Detection: Users can input text or URLs to analyse if it's a scam.
- Scam Reporting: Users (guests or logged in) can report scams via text, URL, or image.
- User Profiles: Logged-in users can update their username, email, password, and profile picture.
- Chatbot: Users can chat with you about how to use the app, but you must not respond to unrelated queries.
- Admin Panel: Admins can review, verify, reject, or delete scam reports. They can also view all users and sessions.
- Chat Sessions: Users can view and rename their own chat sessions. Admins can view all sessions by any user.

Rules:
- If asked about anything outside of this app, reply: “Sorry, I can only assist with IntegrityNet application features.”
- You are not allowed to answer questions about general knowledge, current events, jokes, etc.
"""
                    )
                },
                {"role": "user", "content": chat.message}
            ]
        )

        bot_reply = response.choices[0].message["content"]

        title = None
        if is_new_session:
            cleaned = re.sub(r'[^\w\s]', '', chat.message)
            words = cleaned.strip().split()
            title = ' '.join(words[:6])
            if len(words) > 6:
                title += '...'

        chat_entry = ChatMessage(
            user_id=current_user.id if current_user else None,
            session_id=session_id,
            message=chat.message,
            response=bot_reply,
            title=title
        )

        try:
            db.add(chat_entry)
            db.commit()
            db.refresh(chat_entry)
        except Exception as e:
            db.rollback()
            print(" DB Commit Error:", str(e))
            raise HTTPException(status_code=500, detail="Error saving chat to database.")

        return {
            "session_id": session_id,
            "user_message": chat.message,
            "response": bot_reply
        }

    except OpenAIError as e:
        return {"error": str(e)}

@router.get("/chatbot/history/{session_id}")
def get_chat_history(
    session_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    messages = (
        db.query(ChatMessage)
        .filter(ChatMessage.user_id == current_user.id, ChatMessage.session_id == session_id)
        .order_by(ChatMessage.timestamp.asc())
        .all()
    )

    if not messages:
        raise HTTPException(status_code=404, detail="No messages found for this session.")

    return [
        {
            "message": msg.message,
            "response": msg.response,
            "timestamp": msg.timestamp
        }
        for msg in messages
    ]


@router.get("/chatbot/sessions")
def get_chat_sessions(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    subquery = (
        db.query(
            ChatMessage.session_id,
            func.min(ChatMessage.id).label("min_id")
        )
        .filter(ChatMessage.user_id == current_user.id)
        .group_by(ChatMessage.session_id)
        .subquery()
    )

    sessions = (
        db.query(ChatMessage.session_id, ChatMessage.title)
        .join(subquery, ChatMessage.id == subquery.c.min_id)
        .all()
    )

    return {
        "sessions": [{"session_id": s.session_id, "title": s.title or s.session_id} for s in sessions]
    }

@router.delete("/chatbot/delete/{session_id}")
def delete_chat_session(
    session_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Deletes all messages for a specific chatbot session.
    """
    deleted = (
        db.query(ChatMessage)
        .filter(ChatMessage.user_id == current_user.id, ChatMessage.session_id == session_id)
        .delete()
    )
    db.commit()

    if deleted == 0:
        raise HTTPException(status_code=404, detail="No session found or already deleted.")

    return {"message": f"Session '{session_id}' deleted successfully."}


@router.get("/chatbot/admin/sessions")
def get_all_user_sessions(
    db: Session = Depends(get_db),
    admin_user: User = Depends(get_current_admin)  
):
    """
    Admin-only: Get a list of all chatbot sessions grouped by users.
    """
    from sqlalchemy.orm import joinedload  

    sessions = (
        db.query(ChatMessage)
        .options(joinedload(ChatMessage.user))
        .order_by(ChatMessage.timestamp.desc())
        .all()
    )

    session_dict = {}
    for msg in sessions:
        if msg.session_id not in session_dict:
            session_dict[msg.session_id] = {
                "session_id": msg.session_id,
                "username": msg.user.username if msg.user else None,
                "user_id": msg.user.id if msg.user else None,
                "created_at": msg.timestamp,
            }

    return list(session_dict.values())

@router.get("/chatbot/admin/sessions/{session_id}")
def get_messages_for_session(
    session_id: str,
    db: Session = Depends(get_db),
    admin_user: User = Depends(get_current_admin)
):
    """
    Admin-only: Get all messages for a given session ID.
    Shows both user and chatbot messages clearly.
    """
    messages = (
        db.query(ChatMessage)
        .filter(ChatMessage.session_id == session_id)
        .options(joinedload(ChatMessage.user))
        .order_by(ChatMessage.timestamp)
        .all()
    )

    result = []
    for msg in messages:
        # Add user/admin/guest message
        if msg.message:
            result.append({
                "sender": msg.user.username if msg.user else "Guest",
                "role": msg.user.role if msg.user else "guest",
                "message": msg.message,
                "timestamp": msg.timestamp
            })

        # Add bot response 
        if msg.response:
            result.append({
                "sender": "chatbot",
                "role": "bot",
                "message": msg.response,
                "timestamp": msg.timestamp
            })

    return result

@router.get("/chatbot/admin/user_sessions/{username}")
def get_sessions_by_user(
    username: str,
    db: Session = Depends(get_db),
    admin_user: User = Depends(get_current_admin)
):
    """
    Admin-only: Get all chatbot sessions for a specific user.
    """
    user = db.query(User).filter(User.username == username).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found.")

    sessions = (
        db.query(ChatMessage)
        .filter(ChatMessage.user_id == user.id)
        .order_by(ChatMessage.timestamp.desc())
        .all()
    )

    session_dict = {}
    for msg in sessions:
        if msg.session_id not in session_dict:
            session_dict[msg.session_id] = {
                "session_id": msg.session_id,
                "created_at": msg.timestamp
            }

    return list(session_dict.values())


@router.put("/chatbot/rename/{session_id}")
def rename_session(
    session_id: str,
    data: RenameRequest,  
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    chat = db.query(ChatMessage).filter(ChatMessage.session_id == session_id, ChatMessage.user_id == current_user.id).first()
    if not chat:
        raise HTTPException(status_code=404, detail="Session not found")
    
    chat.title = data.new_title  
    db.commit()
    return {"message": "Title updated"}
