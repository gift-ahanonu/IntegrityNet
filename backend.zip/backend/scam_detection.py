import os
import openai
import re
import requests


# Load OpenAI API Key
openai.api_key = os.getenv("OPENAI_API_KEY")

def analyze_text_with_gpt4(text: str):
    """Uses GPT-4o to detect scam messages and give a confidence-based response."""
    prompt = f"""
    Analyze the following text for scams. Respond with one of these:
    - "yes" (definitely a scam)
    - "very likely" (very suspicious)
    - "less likely" (some risks but not strong evidence)
    - "no" (not a scam)
    
    Also, provide a short explanation (max 2 sentences).
    Example Response: "very likely - The text uses urgency and a suspicious link."

    Text: {text}
    """

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a cybersecurity expert."},
                {"role": "user", "content": prompt}
            ]
        )

        result = response["choices"][0]["message"]["content"].strip()

        if " - " in result:
            return result  
        else:
            return f"Error - Unexpected response format: {result}"

    except Exception as e:
        return f"GPT-4o Error - {e}"

def analyze_url_with_gpt4(url: str):
    """Uses GPT-4o to detect phishing URLs with confidence-based response."""
    prompt = f"""
    Analyze the following URL for scams. Respond with one of these:
    - "yes" (definitely phishing)
    - "very likely" (very suspicious)
    - "less likely" (some risks but not strong evidence)
    - "no" (not phishing)
    
    Also, provide a short explanation (max 2 sentences).
    Example Response: "very likely - The URL contains misleading words and a shortened link."
    
    URL: {url}
    """

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a cybersecurity expert."},
                {"role": "user", "content": prompt}
            ]
        )

        result = response["choices"][0]["message"]["content"].strip()

        if " - " in result:
            return result  
        else:
            return f"Error - Unexpected response format: {result}"

    except Exception as e:
        return f"GPT-4o Error - {e}"
