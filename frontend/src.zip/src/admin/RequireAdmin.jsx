import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "../utils/axios";

const RequireAdmin = ({ children }) => {
  const [isAdmin, setIsAdmin] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) return navigate("/login");

    axios
      .get("/users/me", {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((res) => {
        if (res.data.role === "admin") setIsAdmin(true);
        else navigate("/not-authorized");
      })
      .catch(() => navigate("/login"));
  }, [navigate]);

  if (isAdmin === null) return null;
  return children;
};

export default RequireAdmin;
