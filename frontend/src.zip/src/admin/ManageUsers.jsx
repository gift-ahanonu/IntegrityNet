import { useEffect, useState } from 'react';
import axios from '../utils/axios';
import { Trash2, Search, ShieldCheck } from 'lucide-react';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export default function ManageUsers() {
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const res = await axios.get('/users/admin/users');
      setUsers(res.data);
    } catch (err) {
      console.error('Error loading users:', err);
    }
  };

  const deleteUser = async (id) => {
    if (!window.confirm('Are you sure you want to delete this user?')) return;
    try {
      await axios.delete(`/users/admin/users/${id}`);
      setUsers(users.filter(user => user.id !== id));
      toast.success('User deleted successfully');
    } catch (err) {
      toast.error('Delete failed');
    }
  };

  const toggleAdmin = async (id) => {
    if (!window.confirm('Are you sure you want to toggle this user\'s admin role?')) return;
    try {
      await axios.put(`/users/admin/users/${id}/set-admin`);
      fetchUsers();
      toast.success('User role updated');
    } catch (err) {
      toast.error('Failed to update user role');
    }
  };

  const filteredUsers = users.filter(user =>
    user.username.toLowerCase().includes(search.toLowerCase()) ||
    user.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
          <ShieldCheck className="text-purple-500" /> Manage Users
        </h2>
        <div className="relative w-64">
          <Search className="absolute left-3 top-2.5 text-gray-400" size={16} />
          <input
            type="text"
            placeholder="Search by name or email"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8 pr-4 py-2 w-full border rounded-md text-sm"
          />
        </div>
      </div>

      {filteredUsers.length === 0 ? (
        <p className="text-gray-500 text-center mt-12">No users found.</p>
      ) : (
        <div className="bg-white shadow rounded-xl overflow-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-100 text-gray-600">
                <th className="py-2 px-4 text-left">Username</th>
                <th className="py-2 px-4 text-left">Email</th>
                <th className="py-2 px-4 text-left">Role</th>
                <th className="py-2 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map(user => (
                <tr key={user.id} className="border-b hover:bg-gray-50">
                  <td className="py-2 px-4">{user.username}</td>
                  <td className="py-2 px-4">{user.email}</td>
                  <td className="py-2 px-4">
                    {user.role === 'admin' ? (
                      <span className="text-xs font-medium px-2 py-1 bg-yellow-100 text-yellow-700 rounded-full">Admin</span>
                    ) : (
                      <span className="text-xs font-medium px-2 py-1 bg-gray-100 text-gray-700 rounded-full">User</span>
                    )}
                  </td>
                  <td className="py-2 px-4 text-center flex gap-2 justify-center">
                    <button
                      onClick={() => toggleAdmin(user.id)}
                      className={`px-3 py-1 rounded text-sm font-medium transition ${user.role === 'admin' ? 'bg-yellow-300 text-yellow-900 hover:bg-yellow-400' : 'bg-blue-100 text-blue-700 hover:bg-blue-200'}`}
                    >
                      {user.role === 'admin' ? 'Revoke Admin' : 'Make Admin'}
                    </button>
                    <button
                      onClick={() => deleteUser(user.id)}
                      className="text-red-500 hover:text-red-700"
                      title="Delete user"
                    >
                      <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
