import { useEffect, useState } from 'react';
import axios from '../utils/axios';
import { ShieldCheck, Users, FileText, BarChart, MessageCircle } from 'lucide-react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Bar, XAxis, YAxis, CartesianGrid, Legend, BarChart as ReBarChart } from 'recharts';

const COLORS = ['#8884d8', '#82ca9d', '#ffc658'];

const AdminDashboard = () => {
  const [stats, setStats] = useState({
    total_reports: 0,
    reviewed_reports: 0,
    pending_reports: 0,
    verified_scams: 0,
    scam_type_breakdown: {},
    total_users: 0,
    total_sessions: 0,
  });

  useEffect(() => {
    const fetchAllStats = async () => {
      try {
        const token = localStorage.getItem('token');
        const headers = { Authorization: `Bearer ${token}` };

        const [scamRes, userRes, sessionRes] = await Promise.all([
          axios.get('/scams/stats', { headers }),
          axios.get('/users/admin/users', { headers }),
          axios.get('/chatbot/chatbot/admin/sessions', { headers }),
        ]);

        setStats(prev => ({
          ...prev,
          ...scamRes.data,
          total_users: userRes.data.length,
          total_sessions: sessionRes.data.length
        }));
      } catch (err) {
        console.error('Failed to fetch admin stats', err);
      }
    };

    fetchAllStats();
  }, []);

  const pieData = Object.entries(stats.scam_type_breakdown).map(([type, count]) => ({
    name: type,
    value: count
  }));

  const barData = Object.entries(stats.scam_type_breakdown).map(([type, count]) => ({
    type,
    count
  }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-800 mb-2">📊 Admin Dashboard</h1>
        <p className="text-gray-500">Overview of scam reports and system insights.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={<FileText />} label="Total Reports" value={stats.total_reports} />
        <StatCard icon={<ShieldCheck />} label="Verified Scams" value={stats.verified_scams} />
        <StatCard icon={<Users />} label="Total Users" value={stats.total_users} />
        <StatCard icon={<BarChart />} label="Pending Reports" value={stats.pending_reports} />
        <StatCard icon={<MessageCircle />} label="Chat Sessions" value={stats.total_sessions} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-md">
          <h3 className="text-lg font-semibold mb-4 text-gray-800">📌 Scam Types Pie Chart</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
                label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-md">
          <h3 className="text-lg font-semibold mb-4 text-gray-800">📊 Scam Type Bar Chart</h3>
          <ResponsiveContainer width="100%" height={300}>
            <ReBarChart data={barData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="type" />
              <YAxis allowDecimals={false} />
              <Tooltip />
              <Legend />
              <Bar dataKey="count" fill="#82ca9d" />
            </ReBarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ icon, label, value }) => (
  <div className="bg-white rounded-xl p-4 shadow flex items-center gap-3">
    <div className="bg-blue-100 text-blue-600 p-2 rounded-full">
      {icon}
    </div>
    <div>
      <p className="text-sm text-gray-500">{label}</p>
      <p className="text-xl font-bold">{value}</p>
    </div>
  </div>
);

export default AdminDashboard;
