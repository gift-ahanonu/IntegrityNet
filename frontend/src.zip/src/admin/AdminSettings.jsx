import { useEffect, useState } from "react";
import { Settings, Mail, Lock, Trash2, CheckCircle2 } from "lucide-react";
import axios from "../utils/axios";

export default function AdminSettings() {
  const [email, setEmail] = useState({ new_email: "", confirm_email: "" });
  const [passwords, setPasswords] = useState({
    new_password: "",
    confirm_new_password: "",
  });
  const [message, setMessage] = useState("");

  const handleEmailChange = async () => {
    if (email.new_email !== email.confirm_email)
      return setMessage("Emails do not match");
    try {
      await axios.put("/users/change-email", email);
      setMessage("Email updated!");
      setEmail({ new_email: "", confirm_email: "" });
    } catch (err) {
      setMessage(err.response?.data?.detail || "Failed to change email");
    }
  };

  const handlePasswordChange = async () => {
    if (passwords.new_password !== passwords.confirm_new_password)
      return setMessage("Passwords do not match");
    try {
      await axios.put("/users/change-password", passwords);
      setMessage("Password updated!");
      setPasswords({ new_password: "", confirm_new_password: "" });
    } catch (err) {
      setMessage(err.response?.data?.detail || "Failed to change password");
    }
  };

  const handleDeleteAccount = async () => {
    if (
      !window.confirm(
        "Are you sure you want to delete your account? This action cannot be undone."
      )
    )
      return;
    try {
      await axios.delete("/users/delete-account");
      localStorage.clear();
      window.location.href = "/register";
    } catch (err) {
      setMessage("Account deletion failed.");
    }
  };

  return (
    <div className="max-w-5xl mx-auto mt-10 bg-white rounded-2xl shadow-md p-8">
      <div className="flex gap-4 mb-6 border-b pb-4">
        <h2 className="text-2xl font-bold text-blue-600 flex items-center gap-2">
          <Settings size={28} /> Admin Settings
        </h2>
      </div>

      {message && (
        <div className="text-green-600 flex items-center gap-2 mb-4 text-sm">
          <CheckCircle2 size={16} /> {message}
        </div>
      )}

      {/* Email */}
      <section className="mb-8">
        <h3 className="font-semibold text-lg text-gray-700 mb-2">
          Change Email
        </h3>
        <div className="space-y-3">
          <div className="relative">
            <Mail className="absolute left-3 top-3 text-gray-400" size={18} />
            <input
              type="email"
              placeholder="New email"
              value={email.new_email}
              onChange={(e) =>
                setEmail({ ...email, new_email: e.target.value })
              }
              className="pl-10 w-full border rounded-md p-2 focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="relative">
            <Mail className="absolute left-3 top-3 text-gray-400" size={18} />
            <input
              type="email"
              placeholder="Confirm new email"
              value={email.confirm_email}
              onChange={(e) =>
                setEmail({ ...email, confirm_email: e.target.value })
              }
              className="pl-10 w-full border rounded-md p-2 focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            onClick={handleEmailChange}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md"
          >
            Update Email
          </button>
        </div>
      </section>

      {/* Password */}
      <section className="mb-8">
        <h3 className="font-semibold text-lg text-gray-700 mb-2">
          Change Password
        </h3>
        <div className="space-y-3">
          <div className="relative">
            <Lock className="absolute left-3 top-3 text-gray-400" size={18} />
            <input
              type="password"
              placeholder="New password"
              value={passwords.new_password}
              onChange={(e) =>
                setPasswords({ ...passwords, new_password: e.target.value })
              }
              className="pl-10 w-full border rounded-md p-2 focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-3 text-gray-400" size={18} />
            <input
              type="password"
              placeholder="Confirm new password"
              value={passwords.confirm_new_password}
              onChange={(e) =>
                setPasswords({
                  ...passwords,
                  confirm_new_password: e.target.value,
                })
              }
              className="pl-10 w-full border rounded-md p-2 focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            onClick={handlePasswordChange}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md"
          >
            Update Password
          </button>
        </div>
      </section>

      {/* Danger Zone */}
      <section className="space-y-4">
        <h3 className="text-lg font-semibold text-red-600">Danger Zone</h3>
        <p className="text-sm text-gray-600">
          This action is irreversible. Proceed with caution.
        </p>
        <button
          onClick={handleDeleteAccount}
          className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md flex items-center gap-2"
        >
          <Trash2 size={18} /> Delete My Account
        </button>
      </section>
    </div>
  );
}
