import { useEffect, useState } from "react";
import axios from "../utils/axios";
import { CheckCircle, XCircle, Search, Trash2 } from "lucide-react";

const ScamCard = ({ scam, onReview, onDelete, isPending = false }) => {
  const isImage = scam.scam_type === "image" && scam.content;

  return (
    <div className="border rounded-lg bg-white p-4 shadow flex flex-col gap-2">
      <div className="text-sm text-gray-500">
        {new Date(scam.timestamp).toLocaleString()}
      </div>
      <h3 className="font-semibold text-gray-800">
        {scam.scam_type.toUpperCase()}
      </h3>
      <p className="text-sm text-gray-700">{scam.content}</p>

      {scam.image_path && (
        <img
          src={`http://127.0.0.1:8000/${scam.image_path
            .replace(/\\/g, "/")
            .replace(/^uploads\//, "uploads/")}`}
          alt="Uploaded scam evidence"
          className="max-w-sm border rounded"
          onError={(e) => {
            e.target.onerror = null;
            e.target.src = "/unnamed.png";
          }}
        />
      )}

      {isPending ? (
        <div className="flex gap-4 mt-2">
          <button
            onClick={() => onReview(scam.id, true)}
            className="flex items-center gap-1 text-green-600 hover:text-green-800"
          >
            <CheckCircle size={16} /> Verify
          </button>
          <button
            onClick={() => onReview(scam.id, false)}
            className="flex items-center gap-1 text-red-500 hover:text-red-700"
          >
            <XCircle size={16} /> Reject
          </button>
        </div>
      ) : (
        <div className="flex justify-between items-center mt-2">
          <p className="text-sm font-medium text-gray-600">
            Status:{" "}
            <span
              className={scam.is_verified ? "text-green-600" : "text-red-500"}
            >
              {scam.is_verified ? "Verified" : "Rejected"}
            </span>
          </p>
          <button
            onClick={() => onDelete(scam.id)}
            className="text-red-500 hover:text-red-700"
            title="Delete report"
          >
            <Trash2 size={16} />
          </button>
        </div>
      )}
    </div>
  );
};

const ReviewScams = () => {
  const [scams, setScams] = useState([]);
  const [filter, setFilter] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchScams();
  }, []);

  const fetchScams = async () => {
    setLoading(true);
    try {
      const res = await axios.get("/scams/reported_scams");
      setScams(res.data);
    } catch (err) {
      console.error("Error loading scams:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleReview = async (id, is_verified) => {
    try {
      await axios.put(`/scams/review/${id}`, null, { params: { is_verified } });
      fetchScams();
    } catch (err) {
      console.error("Error reviewing scam:", err);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this scam report?"))
      return;
    try {
      await axios.delete(`/scams/${id}`);
      fetchScams();
    } catch (err) {
      console.error("Failed to delete scam:", err);
    }
  };

  const filtered = scams.filter(
    (scam) =>
      scam.content?.toLowerCase().includes(filter.toLowerCase()) ||
      scam.scam_type?.toLowerCase().includes(filter.toLowerCase())
  );

  const pending = filtered.filter((s) => !s.is_reviewed);
  const reviewed = filtered.filter((s) => s.is_reviewed);

  return (
    <div className="space-y-10">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Review Scam Reports</h2>
        <div className="relative">
          <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
          <input
            type="text"
            placeholder="Search reports..."
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="pl-10 pr-4 py-2 border rounded-md text-sm"
          />
        </div>
      </div>

      {loading ? (
        <p>Loading scam reports...</p>
      ) : (
        <>
          <section className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-700">
              {" "}
              Pending Reports
            </h3>
            {pending.length === 0 ? (
              <p className="text-gray-500 text-sm">No pending reports.</p>
            ) : (
              <div className="grid gap-4">
                {pending.map((scam) => (
                  <ScamCard
                    key={scam.id}
                    scam={scam}
                    onReview={handleReview}
                    isPending
                  />
                ))}
              </div>
            )}
          </section>

          <section className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-700">
              ✅ Reviewed Reports
            </h3>
            {reviewed.length === 0 ? (
              <p className="text-gray-500 text-sm">No reviewed reports yet.</p>
            ) : (
              <div className="grid gap-4">
                {reviewed.map((scam) => (
                  <ScamCard key={scam.id} scam={scam} onDelete={handleDelete} />
                ))}
              </div>
            )}
          </section>
        </>
      )}
    </div>
  );
};

export default ReviewScams;
