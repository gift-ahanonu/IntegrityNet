import { useEffect, useState } from "react";
import axios from "../utils/axios";
import { Search, Eye } from "lucide-react";

export default function ChatbotSessions() {
  const [sessions, setSessions] = useState([]);
  const [selectedSessionId, setSelectedSessionId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [searchUser, setSearchUser] = useState("");

  useEffect(() => {
    fetchSessions();
  }, []);

  const fetchSessions = async () => {
    try {
      const res = await axios.get("/chatbot/chatbot/admin/sessions");
      setSessions(res.data);
    } catch (err) {
      console.error("Error loading sessions:", err);
    }
  };

  const loadMessages = async (sessionId) => {
    try {
      const res = await axios.get(
        `/chatbot/chatbot/admin/sessions/${sessionId}`
      );
      console.log("Session Data:", res.data);
      setMessages(res.data);
      setSelectedSessionId(sessionId);
    } catch (err) {
      alert("Failed to load session messages");
    }
  };

  const filteredSessions = sessions.filter(
    (s) =>
      s.username?.toLowerCase().includes(searchUser.toLowerCase()) ||
      (s.user_id === null && "guest".includes(searchUser.toLowerCase()))
  );

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">
          All Chatbot Sessions
        </h2>
        <div className="relative w-64">
          <Search className="absolute left-3 top-2.5 text-gray-400" size={16} />
          <input
            type="text"
            placeholder="Search by username"
            value={searchUser}
            onChange={(e) => setSearchUser(e.target.value)}
            className="pl-8 pr-4 py-2 w-full border rounded-md text-sm"
          />
        </div>
      </div>

      <div className="bg-white shadow rounded-xl overflow-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-gray-100 text-gray-600">
              <th className="py-2 px-4 text-left">Session ID</th>
              <th className="py-2 px-4 text-left">User</th>
              <th className="py-2 px-4">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredSessions.map((s) => (
              <tr key={s.session_id} className="border-b hover:bg-gray-50">
                <td className="py-2 px-4 break-all">{s.session_id}</td>
                <td className="py-2 px-4">{s.username || "Guest"}</td>
                <td className="py-2 px-4 text-center">
                  <button
                    onClick={() => loadMessages(s.session_id)}
                    className="text-blue-600 hover:text-blue-800 flex items-center gap-1"
                  >
                    <Eye size={16} /> View
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedSessionId && (
        <div className="bg-white rounded-xl shadow-md p-4 mt-6">
          <h3 className="text-lg font-semibold mb-2 text-blue-700">
            Conversation for Session: {selectedSessionId}
          </h3>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {messages.map((msg, i) => (
              <div
                key={i}
                className={`flex ${
                  msg.role === "bot" ? "justify-start" : "justify-end"
                }`}
              >
                <div
                  className={`px-4 py-2 max-w-md rounded-lg shadow ${
                    msg.role === "bot" ? "bg-green-100" : "bg-blue-100"
                  }`}
                >
                  <p className="text-sm text-gray-800 whitespace-pre-wrap">
                    {msg.role === "bot"
                      ? "🤖 chatbot"
                      : `👤 ${msg.sender || "Guest"}`}
                    : {msg.message || "[No content]"}
                  </p>
                  {msg.timestamp && (
                    <small className="block text-xs text-gray-400 mt-1">
                      {new Date(msg.timestamp).toLocaleString()}
                    </small>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
