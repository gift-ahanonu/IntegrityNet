import { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import {
  Home,
  Bot,
  FileText,
  Settings,
  LogOut,
  ShieldCheck,
  Users,
} from 'lucide-react';
import Navbar from '../components/Navbar';

const AdminLayout = () => {
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();

  const links = [
    { to: '/admin', label: 'Dashboard', icon: <Home size={20} /> },
    { to: '/admin/users', label: 'Users', icon: <Users size={20} /> },
    { to: '/admin/scams', label: 'Scams', icon: <ShieldCheck size={20} /> },
    { to: '/admin/chatbot', label: 'Chatbot Sessions', icon: <Bot size={20} /> },
    { to: '/admin/settings', label: 'Settings', icon: <Settings size={20} /> },
  ];

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className={`transition-all duration-300 bg-white border-r shadow-md p-4 flex flex-col justify-between ${collapsed ? 'w-20' : 'w-64'}`}>
        <div>
          {/* Header */}
          <div className="flex justify-between items-center mb-6">
            <h2 className={`text-xl font-bold text-blue-600 transition-opacity duration-300 ${collapsed ? 'opacity-0 w-0 overflow-hidden' : 'opacity-100'}`}>
              Integrity Admin
            </h2>
            <button onClick={() => setCollapsed(!collapsed)} className="text-blue-600">
              {collapsed ? '☰' : '✕'}
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-2">
            {links.map(link => (
              <NavLink
                key={link.to}
                to={link.to}
                end={link.to === '/admin'}
                className={({ isActive }) =>
                  `flex items-center gap-3 p-2 rounded-md text-sm font-medium transition whitespace-nowrap overflow-hidden ${
                    isActive
                      ? 'bg-blue-100 text-blue-700'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`
                }
              >
                {link.icon}
                {!collapsed && <span>{link.label}</span>}
              </NavLink>
            ))}
          </nav>
        </div>

        {/* Logout */}
        <button
          onClick={() => setShowLogoutConfirm(true)}
          className="flex items-center gap-3 p-2 rounded-md text-sm font-medium text-red-500 hover:bg-red-100"
        >
          <LogOut size={20} />
          {!collapsed && <span>Logout</span>}
        </button>

        {/* Logout Confirmation */}
        {showLogoutConfirm && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
            <div className="bg-white p-6 rounded shadow-md text-center w-80">
              <h3 className="text-lg font-semibold mb-4">Confirm Logout</h3>
              <p className="text-gray-600 mb-6">Are you sure you want to log out?</p>
              <div className="flex justify-center gap-4">
                <button
                  onClick={() => setShowLogoutConfirm(false)}
                  className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400"
                >
                  Cancel
                </button>
                <button
                  onClick={handleLogout}
                  className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
                >
                  Logout
                </button>
              </div>
            </div>
          </div>
        )}
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        <Navbar />
        <main className="p-6 overflow-y-auto h-full">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
