import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell } from 'lucide-react';
import axios from '../utils/axios';

const Navbar = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [profileError, setProfileError] = useState(false);

  const token = localStorage.getItem('token');

  useEffect(() => {
    if (!token) {
      setUser(null);
      return;
    }

    axios
      .get('/users/me', { headers: { Authorization: `Bearer ${token}` } })
      .then((res) => setUser(res.data))
      .catch(() => setUser(null));
  }, [token]);

  const profileSrc =
    !profileError && user?.profile_picture
      ? `http://127.0.0.1:8000/static/profile_pics/${user.profile_picture}`
      : null;

  return (
    <header className="w-full bg-white border-b px-6 py-4 shadow-sm flex items-center justify-between">
      <h1 className="text-lg font-semibold text-gray-800">
        {user ? `Welcome back, ${user.username} 👋` : 'Welcome to IntegrityNet 👋'}
      </h1>

      <div className="flex items-center gap-4">
        {user ? (
          <button
            onClick={() => navigate('/settings')}
            className="flex items-center gap-2 text-gray-700 hover:text-blue-600"
          >
            {profileSrc ? (
              <img
                src={profileSrc}
                alt="Profile"
                className="w-8 h-8 rounded-full object-cover border"
                onError={() => setProfileError(true)}
              />
            ) : (
              <div className="w-8 h-8 rounded-full border flex items-center justify-center bg-gray-100">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5 text-gray-400"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5.121 17.804A13.937 13.937 0 0112 15c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0z"
                  />
                </svg>
              </div>
            )}
            <span
  className="hidden sm:inline text-sm font-medium cursor-pointer hover:underline"
  onClick={() =>
    user?.role === 'admin'
      ? navigate('/admin/settings')
      : navigate('/admin/settings')
  }
>
  {user.username}
</span>

          </button>
        ) : (
          <div className="flex gap-2">
            <button
              onClick={() => navigate('/register')}
              className="px-4 py-1 text-sm text-blue-600 border border-blue-600 rounded hover:bg-blue-50"
            >
              Register
            </button>
            <button
              onClick={() => navigate('/login')}
              className="px-4 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700"
            >
              Login
            </button>
            <button
              onClick={() => navigate('/login')}
              className="px-4 py-1 text-sm bg-gray-700 text-white rounded hover:bg-gray-800"
            >
              Admin Login
            </button>
          </div>
        )}
      </div>
    </header>
  );
};

export default Navbar;
