import { useState } from 'react';
import axios from '../utils/axios';
import { useNavigate, Link } from 'react-router-dom';
import { Loader2 } from 'lucide-react';

export default function Login() {
  const [form, setForm] = useState({ username: '', password: '' });
  const [email, setEmail] = useState('');
  const [forgotVisible, setForgotVisible] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setError('');
    setSuccess('');
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const formData = new URLSearchParams();
      formData.append('username', form.username);
      formData.append('password', form.password);

      const res = await axios.post('/users/token', formData, {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
      });

      const token = res.data.access_token;
      localStorage.setItem('token', token);
      const payload = JSON.parse(atob(token.split('.')[1]));
      const role = payload.role;

      navigate(role === 'admin' ? '/admin' : '/admin');
    } catch (err) {
      setError(err.response?.data?.detail || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await axios.post('/users/reset-password-request', { email });
      setSuccess(res.data.message || 'Check your email for reset instructions.');
    } catch (err) {
      setError(err.response?.data?.detail || 'Could not send reset email');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex text-lg">
      {/* Left Side */}
      <div className="hidden lg:flex w-1/2 bg-gradient-to-tr from-blue-700 to-blue-900 text-white items-center justify-center p-16">
        <div className="max-w-lg space-y-10">
          <img src="/favicon.png" alt="Logo" className="h-32 w-32" />
          <h2 className="text-5xl font-extrabold leading-tight">Welcome Back</h2>
          <p className="text-xl opacity-90">
            Detect and report scams with ease. Protect your identity and help keep others safe online.
          </p>
          <div className="flex gap-6 text-white text-2xl">
            <i className="fab fa-facebook-f"></i>
            <i className="fab fa-x-twitter"></i>
            <i className="fab fa-instagram"></i>
            <i className="fab fa-linkedin-in"></i>
          </div>
        </div>
      </div>

      {/* Right Side */}
      <div className="w-full lg:w-1/2 flex items-center justify-center bg-white p-12">
        <div className="w-full max-w-xl space-y-8">
          <div>
            <h2 className="text-4xl font-bold text-gray-800 text-center">Sign in</h2>
            {error && <p className="text-red-600 text-md mt-3 text-center">{error}</p>}
            {success && <p className="text-green-600 text-md mt-3 text-center">{success}</p>}
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <input
              className="w-full border border-gray-300 rounded-xl px-5 py-3 text-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              name="username"
              placeholder="Username"
              value={form.username}
              onChange={handleChange}
              required
            />
            <input
              className="w-full border border-gray-300 rounded-xl px-5 py-3 text-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              type="password"
              name="password"
              placeholder="Password"
              value={form.password}
              onChange={handleChange}
              required
            />
            <div className="flex justify-between items-center text-md">
              <label className="flex items-center gap-2 text-gray-600">
                <input type="checkbox" className="accent-blue-600 h-4 w-4" />
                Remember Me
              </label>
              <button
                type="button"
                onClick={() => setForgotVisible(!forgotVisible)}
                className="text-blue-600 hover:underline text-base"
              >
                Forgot Password?
              </button>
            </div>
            <button
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white py-3 rounded-xl hover:bg-blue-700 text-lg font-semibold transition disabled:opacity-50"
            >
              {loading && <Loader2 className="animate-spin h-5 w-5" />}
              {loading ? 'Logging in...' : 'Sign in now'}
            </button>
          </form>

          {forgotVisible && (
            <form onSubmit={handleForgotPassword} className="space-y-4 border-t pt-6 mt-6">
              <input
                className="w-full border border-gray-300 rounded-xl px-5 py-3 text-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <button
                type="submit"
                className="w-full bg-gray-700 hover:bg-gray-800 text-white py-3 rounded-xl transition text-lg font-semibold"
              >
                Send Reset Link
              </button>
            </form>
          )}

          <p className="text-center text-base text-gray-600">
            Don’t have an account?{' '}
            <Link to="/register" className="text-blue-600 hover:underline font-semibold">
              Register
            </Link>
          </p>
          <p className="text-sm text-gray-500 text-center mt-4">
            By signing in you agree to our <Link to="/terms" className="underline text-blue-600">Terms of Service</Link> and <Link to="/privacy" className="underline text-blue-600">Privacy Policy</Link>.

          </p>
        </div>
      </div>
    </div>
  );
}
