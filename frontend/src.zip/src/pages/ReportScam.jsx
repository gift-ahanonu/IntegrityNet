import { useState } from "react";
import axios from "../utils/axios";
import { Link, useNavigate } from "react-router-dom";
import {
  UploadCloud,
  Loader2,
  CheckCircle,
  XCircle,
  LogIn,
} from "lucide-react";

export default function ReportScam() {
  const [form, setForm] = useState({
    scam_type: "text",
    content: "",
    file: null,
    reported_by: "",
    description: "",
  });
  const [status, setStatus] = useState({ message: "", type: "" });
  const [submitting, setSubmitting] = useState(false);
  const isLoggedIn = !!localStorage.getItem("token");
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: files ? files[0] : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setStatus({ message: "", type: "" });

    try {
      const formData = new FormData();
      formData.append("scam_type", form.scam_type);
      formData.append("content", form.content);
      formData.append("reported_by", form.reported_by);
      if (form.description) formData.append("description", form.description);
      if (form.file && form.scam_type === "image") {
        formData.append("image", form.file);
      }

      await axios.post("/scams/report_scam", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      setStatus({
        message: "Scam report submitted successfully. Thank you!",
        type: "success",
      });
      setForm({
        scam_type: "text",
        content: "",
        file: null,
        reported_by: "",
        description: "",
      });
    } catch {
      setStatus({ message: "Failed to submit report.", type: "error" });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-6 py-10">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold text-indigo-700 flex items-center gap-2">
          <UploadCloud className="w-6 h-6" />
          Report a Scam
        </h2>
        <Link to="/" className="text-blue-600 hover:underline text-sm">
          ← Back to Homepage
        </Link>
      </div>

      <p className="text-gray-600 mb-4">
        Help others stay safe by reporting suspicious content, links, or
        screenshots.
      </p>

      {!isLoggedIn && (
        <div className="bg-yellow-100 text-yellow-800 px-4 py-3 rounded-md mb-6 text-sm flex items-center justify-between">
          <p>
            ⚠️ You are not signed in. Reports can still be submitted, but you
            won’t receive feedback or status updates.
          </p>
          <button
            onClick={() => navigate("/login")}
            className="ml-4 inline-flex items-center bg-yellow-600 hover:bg-yellow-700 text-white px-3 py-1.5 rounded-md text-sm"
          >
            <LogIn className="w-4 h-4 mr-1" />
            Sign In
          </button>
        </div>
      )}

      {status.message && (
        <div
          className={`mb-4 px-4 py-2 rounded text-sm font-medium flex items-center gap-2 ${
            status.type === "success"
              ? "bg-green-100 text-green-700"
              : "bg-red-100 text-red-700"
          }`}
        >
          {status.type === "success" ? (
            <CheckCircle size={16} />
          ) : (
            <XCircle size={16} />
          )}
          {status.message}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1 font-medium">Scam Type</label>
          <select
            name="scam_type"
            value={form.scam_type}
            onChange={handleChange}
            className="w-full border border-gray-300 p-2 rounded-md"
          >
            <option value="text">Text</option>
            <option value="url">URL</option>
            <option value="image">Image</option>
          </select>
        </div>

        {(form.scam_type === "text" || form.scam_type === "url") && (
          <div>
            <label className="block mb-1 font-medium">
              {form.scam_type === "text" ? "Suspicious Text" : "Suspicious URL"}
            </label>
            <textarea
              name="content"
              rows="3"
              className="w-full border border-gray-300 p-2 rounded-md"
              value={form.content}
              onChange={handleChange}
              required
            />
          </div>
        )}

        {form.scam_type === "image" && (
          <div>
            <label className="block mb-1 font-medium">Upload Image</label>
            <input
              type="file"
              name="file"
              accept="image/*"
              className="w-full border border-gray-300 p-2 rounded-md"
              onChange={handleChange}
              required
            />
          </div>
        )}

        <div>
          <label className="block mb-1 font-medium">Username</label>
          <input
            name="reported_by"
            value={form.reported_by}
            onChange={handleChange}
            className="w-full border border-gray-300 p-2 rounded-md"
            required
          />
        </div>

        <div>
          <label className="block mb-1 font-medium">Optional Description</label>
          <textarea
            name="description"
            rows="2"
            value={form.description}
            onChange={handleChange}
            className="w-full border border-gray-300 p-2 rounded-md"
          />
        </div>

        <button
          disabled={submitting}
          className="w-full bg-indigo-600 text-white py-2 rounded-md hover:bg-indigo-700 flex items-center justify-center gap-2 font-medium"
        >
          {submitting ? (
            <Loader2 size={16} className="animate-spin" />
          ) : (
            <UploadCloud size={16} />
          )}
          {submitting ? "Submitting..." : "Submit Scam Report"}
        </button>
      </form>
    </div>
  );
}
