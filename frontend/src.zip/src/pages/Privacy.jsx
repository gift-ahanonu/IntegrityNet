export default function Privacy() {
  return (
    <div className="max-w-3xl mx-auto px-6 py-12">
      <h1 className="text-3xl font-bold mb-6">Privacy Policy</h1>
      <p className="text-gray-700 mb-4">
        Your privacy is important to us. IntegrityNet collects only the
        necessary information to provide our services. This may include your
        name, email address, and usage data.
      </p>
      <p className="text-gray-700 mb-4">
        We do not sell or share your personal data with third parties. All
        information is securely stored and used only for the purpose of
        improving our platform.
      </p>
      <p className="text-gray-700 mb-4">
        You can request deletion of your data or ask questions by emailing
        integritynet.team@gmail.com.
      </p>
    </div>
  );
}
