import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "../utils/axios";
import { AlertCircle } from "lucide-react";

const Reports = () => {
  const [reports, setReports] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [typeFilter, setTypeFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [openReportId, setOpenReportId] = useState(null);
  const [error, setError] = useState("");
  const reportsPerPage = 5;
  const [page, setPage] = useState(1);

  useEffect(() => {
    fetchReports();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [typeFilter, statusFilter, reports]);

  const fetchReports = async () => {
    try {
      const res = await axios.get("/scams/my_reports");
      if (Array.isArray(res.data)) {
        setReports(res.data);
      } else {
        setReports([]);
      }
    } catch (err) {
      setError("Failed to load reports. Please make sure you are logged in.");
      setReports([]);
    }
  };

  const applyFilters = () => {
    let data = [...reports];
    if (typeFilter !== "all")
      data = data.filter((r) => r.scam_type === typeFilter);
    if (statusFilter !== "all") {
      if (statusFilter === "pending") data = data.filter((r) => !r.is_reviewed);
      else if (statusFilter === "reviewed")
        data = data.filter((r) => r.is_reviewed && !r.is_verified);
      else if (statusFilter === "verified")
        data = data.filter((r) => r.is_verified);
    }
    setFiltered(data);
    setPage(1);
  };

  const deleteReport = async (id) => {
    if (!window.confirm("Are you sure you want to delete this report?")) return;
    try {
      await axios.delete(`/scams/delete/${id}`);
      setReports(reports.filter((r) => r.id !== id));
    } catch {
      alert("Failed to delete report.");
    }
  };

  const currentReports = filtered.slice(
    (page - 1) * reportsPerPage,
    page * reportsPerPage
  );
  const totalPages = Math.ceil(filtered.length / reportsPerPage);

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-10">
      <div className="flex justify-between items-center border-b pb-4">
        <div>
          <h2 className="text-4xl font-extrabold text-gray-900 flex items-center gap-2">
            <span role="img" aria-label="document">
              📄
            </span>{" "}
            My Scam Reports
          </h2>
          <p className="text-sm text-gray-500">
            Track your reported scams and manage them easily.
          </p>
        </div>
        <Link
          to="/report-scam"
          className="flex items-center gap-2 bg-blue-600 text-white px-5 py-2.5 rounded-lg hover:bg-blue-700 transition shadow"
        >
          <AlertCircle size={18} /> Report Scam
        </Link>
      </div>

      {error && (
        <div className="bg-red-100 border border-red-300 text-red-700 p-4 rounded-lg">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 lg:flex lg:gap-6">
        <select
          onChange={(e) => setTypeFilter(e.target.value)}
          value={typeFilter}
          className="flex-1 border rounded-lg px-4 py-2 bg-white shadow-sm focus:ring-2 focus:ring-blue-500"
        >
          <option value="all">All Types</option>
          <option value="text">Text</option>
          <option value="url">URL</option>
          <option value="image">Image</option>
        </select>
        <select
          onChange={(e) => setStatusFilter(e.target.value)}
          value={statusFilter}
          className="flex-1 border rounded-lg px-4 py-2 bg-white shadow-sm focus:ring-2 focus:ring-blue-500"
        >
          <option value="all">All Status</option>
          <option value="pending">Pending</option>
          <option value="reviewed">Reviewed</option>
          <option value="verified">Verified</option>
        </select>
      </div>

      {currentReports.length === 0 ? (
        <div className="text-center text-gray-500 text-lg py-12">
          No reports to show.
        </div>
      ) : (
        <div className="grid gap-6 sm:grid-cols-1 md:grid-cols-2">
          {currentReports.map((report) => (
            <div
              key={report.id}
              className="bg-white shadow-md hover:shadow-lg transition rounded-xl p-6 space-y-3 border border-gray-100"
            >
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm text-gray-400">
                    {new Date(report.timestamp).toLocaleString()}
                  </p>
                  <h4 className="text-lg font-bold text-gray-800">
                    {report.scam_type.toUpperCase()}
                  </h4>
                  <p className="text-gray-600 text-sm line-clamp-2">
                    {report.content || "No content provided."}
                  </p>
                </div>
                <span
                  className={`text-xs font-semibold px-2 py-1 rounded-full ${
                    report.is_verified
                      ? "bg-green-100 text-green-700"
                      : report.is_reviewed
                      ? "bg-yellow-100 text-yellow-700"
                      : "bg-red-100 text-red-600"
                  }`}
                >
                  {report.is_verified
                    ? "Verified"
                    : report.is_reviewed
                    ? "Reviewed"
                    : "Pending"}
                </span>
              </div>

              <div className="flex gap-4 text-sm">
                <button
                  onClick={() =>
                    setOpenReportId(
                      openReportId === report.id ? null : report.id
                    )
                  }
                  className="text-blue-600 hover:underline"
                >
                  {openReportId === report.id ? "Hide Details" : "View Details"}
                </button>
                <button
                  onClick={() => deleteReport(report.id)}
                  className="text-red-500 hover:underline"
                >
                  Delete
                </button>
              </div>

              {openReportId === report.id && (
                <div className="mt-3 bg-gray-50 p-4 rounded-lg text-sm border border-gray-200">
                  <p className="mb-2">
                    <strong>Description:</strong>{" "}
                    {report.description || "No description provided."}
                  </p>
                  {report.image_path && (
                    <div>
                      <p className="font-medium mb-1">Screenshot:</p>
                      <img
                        src={`http://127.0.0.1:8000/${report.image_path
                          .replace(/\\/g, "/")
                          .replace(/^uploads\//, "uploads/")}`}
                        alt="Screenshot"
                        className="rounded border w-full max-h-64 object-contain"
                        onError={(e) => {
                          e.target.onerror = null;
                          e.target.src = "/unnamed.png";
                        }}
                      />
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {totalPages > 1 && (
        <div className="mt-8 flex justify-center flex-wrap gap-2">
          {Array.from({ length: totalPages }, (_, i) => (
            <button
              key={i}
              onClick={() => setPage(i + 1)}
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition ${
                page === i + 1
                  ? "bg-blue-600 text-white"
                  : "bg-gray-200 text-gray-800 hover:bg-gray-300"
              }`}
            >
              {i + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default Reports;
