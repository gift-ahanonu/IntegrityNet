import { useEffect, useState } from "react";
import axios from "../utils/axios";
import { User, Mail, Lock, Trash2 } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function ProfileSettings() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("account");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState({ new_email: "", confirm_email: "" });
  const [passwords, setPasswords] = useState({
    current_password: "",
    new_password: "",
    confirm_new_password: "",
  });
  const [profileImage, setProfileImage] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [message, setMessage] = useState("");
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) return navigate("/login");

    axios
      .get("/users/me", { headers: { Authorization: `Bearer ${token}` } })
      .then((res) => setUserData(res.data))
      .catch(() => navigate("/login"));
  }, [navigate]);

  const refreshUser = async () => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.get("/users/me", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUserData(res.data);
    } catch {}
  };

  const handleUsernameChange = async () => {
    try {
      await axios.put("/users/change-username", { new_username: username });
      setMessage("Username updated!");
      setUsername("");
      refreshUser();
    } catch (err) {
      setMessage(err.response?.data?.detail || "Failed to change username");
    }
  };

  const handleEmailChange = async () => {
    if (email.new_email !== email.confirm_email)
      return setMessage("Emails do not match");
    try {
      await axios.put("/users/change-email", email);
      setMessage("Email updated!");
      setEmail({ new_email: "", confirm_email: "" });
    } catch (err) {
      setMessage(err.response?.data?.detail || "Failed to change email");
    }
  };

  const handlePasswordChange = async () => {
    if (passwords.new_password !== passwords.confirm_new_password)
      return setMessage("Passwords do not match");
    try {
      await axios.put("/users/change-password", passwords);
      setMessage("Password changed!");
      setPasswords({
        current_password: "",
        new_password: "",
        confirm_new_password: "",
      });
    } catch (err) {
      setMessage(err.response?.data?.detail || "Failed to change password");
    }
  };

  const handleDeleteAccount = async () => {
    if (
      !window.confirm(
        "Are you sure you want to delete your account? This action cannot be undone."
      )
    )
      return;
    try {
      await axios.delete("/users/delete-account");
      localStorage.clear();
      window.location.href = "/register";
    } catch (err) {
      setMessage("Account deletion failed.");
    }
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    setProfileImage(file);
    setPreviewUrl(URL.createObjectURL(file));

    const formData = new FormData();
    formData.append("file", file);

    try {
      await axios.post("/users/upload-picture", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setMessage("Profile picture updated!");
      refreshUser();
    } catch {
      setMessage(" Failed to upload image");
    }
  };

  const handleRemovePicture = async () => {
    try {
      await axios.put("/users/remove-picture");
      setMessage("Profile picture removed!");
      setPreviewUrl(null);
      refreshUser();
    } catch {
      setMessage(" Failed to remove picture");
    }
  };

  return (
    <div className="max-w-5xl mx-auto mt-10 bg-white rounded-2xl shadow-md p-8">
      <div className="flex gap-4 mb-6 border-b pb-4">
        <button
          onClick={() => setActiveTab("account")}
          className={`text-sm font-medium ${
            activeTab === "account"
              ? "text-blue-600 border-b-2 border-blue-600"
              : "text-gray-600"
          }`}
        >
          Account Settings
        </button>
        <button
          onClick={() => setActiveTab("privacy")}
          className={`text-sm font-medium ${
            activeTab === "privacy"
              ? "text-blue-600 border-b-2 border-blue-600"
              : "text-gray-600"
          }`}
        >
          Privacy
        </button>
      </div>

      {message && <div className="text-green-600 text-sm mb-4">{message}</div>}

      {activeTab === "account" && (
        <>
          {/* Profile Picture */}
          <section className="mb-8">
            <h3 className="font-semibold text-lg text-gray-700 mb-2">
              Profile Picture
            </h3>
            <div className="flex items-center gap-6">
              {previewUrl || userData?.profile_picture ? (
                <img
                  src={
                    previewUrl ||
                    `http://127.0.0.1:8000/static/profile_pics/${userData?.profile_picture}`
                  }
                  alt="Profile"
                  className="h-16 w-16 rounded-full object-cover border"
                  onError={(e) => {
                    e.target.onerror = null;
                    setPreviewUrl(null);
                    setUserData((prev) => ({ ...prev, profile_picture: null }));
                  }}
                />
              ) : (
                <div className="h-16 w-16 rounded-full border flex items-center justify-center bg-gray-100">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 text-gray-400"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M5.121 17.804A13.937 13.937 0 0112 15c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0z"
                    />
                  </svg>
                </div>
              )}

              <div className="space-y-2">
                <input
                  type="file"
                  onChange={handleImageUpload}
                  className="text-sm"
                />

                {(previewUrl || userData?.profile_picture) && (
                  <button
                    onClick={handleRemovePicture}
                    className="text-red-600 text-sm underline"
                  >
                    Remove Picture
                  </button>
                )}
              </div>
            </div>
          </section>

          {/* Username */}
          <section className="mb-8">
            <h3 className="font-semibold text-lg text-gray-700 mb-2">
              Change Username
            </h3>
            <div className="flex gap-4 items-center">
              <div className="relative w-full">
                <User
                  className="absolute left-3 top-3 text-gray-400"
                  size={18}
                />
                <input
                  type="text"
                  placeholder="New username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="pl-10 w-full border rounded-md p-2 focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <button
                onClick={handleUsernameChange}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md"
              >
                Update
              </button>
            </div>
          </section>

          {/* Email */}
          <section className="mb-8">
            <h3 className="font-semibold text-lg text-gray-700 mb-2">
              Change Email
            </h3>
            <div className="space-y-3">
              <div className="relative">
                <Mail
                  className="absolute left-3 top-3 text-gray-400"
                  size={18}
                />
                <input
                  type="email"
                  placeholder="New email"
                  value={email.new_email}
                  onChange={(e) =>
                    setEmail({ ...email, new_email: e.target.value })
                  }
                  className="pl-10 w-full border rounded-md p-2 focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="relative">
                <Mail
                  className="absolute left-3 top-3 text-gray-400"
                  size={18}
                />
                <input
                  type="email"
                  placeholder="Confirm new email"
                  value={email.confirm_email}
                  onChange={(e) =>
                    setEmail({ ...email, confirm_email: e.target.value })
                  }
                  className="pl-10 w-full border rounded-md p-2 focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <button
                onClick={handleEmailChange}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md"
              >
                Update Email
              </button>
            </div>
          </section>

          {/* Password */}
          <section className="mb-8">
            <h3 className="font-semibold text-lg text-gray-700 mb-2">
              Change Password
            </h3>
            <div className="space-y-3">
              <div className="relative">
                <Lock
                  className="absolute left-3 top-3 text-gray-400"
                  size={18}
                />
                <input
                  type="password"
                  placeholder="Current password"
                  value={passwords.current_password}
                  onChange={(e) =>
                    setPasswords({
                      ...passwords,
                      current_password: e.target.value,
                    })
                  }
                  className="pl-10 w-full border rounded-md p-2 focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="relative">
                <Lock
                  className="absolute left-3 top-3 text-gray-400"
                  size={18}
                />
                <input
                  type="password"
                  placeholder="New password"
                  value={passwords.new_password}
                  onChange={(e) =>
                    setPasswords({ ...passwords, new_password: e.target.value })
                  }
                  className="pl-10 w-full border rounded-md p-2 focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="relative">
                <Lock
                  className="absolute left-3 top-3 text-gray-400"
                  size={18}
                />
                <input
                  type="password"
                  placeholder="Confirm new password"
                  value={passwords.confirm_new_password}
                  onChange={(e) =>
                    setPasswords({
                      ...passwords,
                      confirm_new_password: e.target.value,
                    })
                  }
                  className="pl-10 w-full border rounded-md p-2 focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <button
                onClick={handlePasswordChange}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md"
              >
                Change Password
              </button>
            </div>
          </section>
        </>
      )}

      {activeTab === "privacy" && (
        <section className="space-y-4">
          <h3 className="text-lg font-semibold text-red-600">Danger Zone</h3>
          <p className="text-sm text-gray-600">
            You can permanently delete your account here. This action cannot be
            undone.
          </p>
          <button
            onClick={handleDeleteAccount}
            className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md flex items-center gap-2"
          >
            <Trash2 size={18} /> Delete My Account
          </button>
        </section>
      )}
    </div>
  );
}
