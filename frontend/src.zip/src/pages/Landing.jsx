import { useState } from "react";
import axios from "../utils/axios";
import {
  ShieldCheck,
  Globe,
  ImageIcon,
  Loader2,
  BarChart,
  Megaphone,
} from "lucide-react";
import { Link } from "react-router-dom";

export default function Landing() {
  const [text, setText] = useState("");
  const [url, setUrl] = useState("");
  const [image, setImage] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const isLoggedIn = !!localStorage.getItem("token");

  const limitCheck = (key) => {
    const count = parseInt(localStorage.getItem(key)) || 0;
    if (!isLoggedIn && count >= 2) {
      alert("Guest limit reached. Please login to continue.");
      return false;
    }
    if (!isLoggedIn) localStorage.setItem(key, count + 1);
    return true;
  };

  const analyzeText = async () => {
    if (!limitCheck("text_analysis_count")) return;
    try {
      setLoading(true);
      const res = await axios.post("/scams/analyze_text", { content: text });
      setResult({ ...res.data, type: "text" });
    } catch {
      setResult({ error: " Error analysing text." });
    } finally {
      setLoading(false);
    }
  };

  const analyzeURL = async () => {
    if (!limitCheck("url_analysis_count")) return;
    try {
      setLoading(true);
      const res = await axios.post("/scams/analyze_url", { content: url });
      setResult({ ...res.data, type: "url" });
    } catch {
      setResult({ error: " Error analysing URL." });
    } finally {
      setLoading(false);
    }
  };

  const uploadImage = async () => {
    if (!limitCheck("image_analysis_count")) return;
    try {
      setLoading(true);
      const formData = new FormData();
      formData.append("file", image);
      const res = await axios.post("/scams/upload_screenshot", formData);
      setResult({ ...res.data, type: "image" });
    } catch {
      setResult({ error: "Error uploading image." });
    } finally {
      setLoading(false);
    }
  };

  const renderResult = () => {
    if (!result || result.error)
      return (
        result?.error && (
          <p className="text-red-600 text-center text-md font-medium mt-6">
            {result.error}
          </p>
        )
      );

    return (
      <div className="bg-white border-l-4 border-indigo-500 p-6 rounded-2xl shadow-lg space-y-4 animate-fade-in">
        <h3 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
          <BarChart className="text-indigo-600" />
          Analysis Result
        </h3>
        <p className="text-gray-700">
          <strong>Scam Detected:</strong>{" "}
          <span
            className={result.scam_detected ? "text-red-600" : "text-green-600"}
          >
            {result.scam_detected ? "Yes" : "No"}
          </span>
        </p>

        {result.text_explanation && result.confidence !== "Error" && (
          <div>
            <h4 className="font-semibold text-gray-800 mb-1">
              📝 Text Analysis
            </h4>
            <p>
              <strong>Confidence:</strong> {result.confidence}
            </p>
            <p>
              <strong>Explanation:</strong> {result.text_explanation}
            </p>
          </div>
        )}

        {result.explanation && (
          <div>
            <h4 className="font-semibold text-gray-800 mb-1">
              🌐 URL Analysis
            </h4>
            <p>
              <strong>Confidence:</strong> {result.confidence}
            </p>
            <p>
              <strong>Explanation:</strong> {result.explanation}
            </p>
          </div>
        )}

        {result.qr_code_detected && (
          <div>
            <h4 className="font-semibold text-gray-800 mb-1">
              📷 QR Code Detected
            </h4>
            <p>
              <strong>Content:</strong> {result.qr_code_content}
            </p>
            <p>
              <strong>Confidence:</strong> {result.qr_confidence}
            </p>
            <p>
              <strong>Explanation:</strong> {result.qr_explanation}
            </p>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-white px-6 py-12">
      <div className="max-w-6xl mx-auto space-y-16">
        {/* HEADER */}
        <div className="text-center space-y-4">
          <div className="flex justify-center items-center gap-3">
            <img
              src="/favicon.png"
              alt="IntegrityNet Logo"
              className="h-14 w-14"
            />
            <h1 className="text-5xl font-extrabold text-gray-900">
              IntegrityNet
            </h1>
          </div>

          <p className="text-gray-600 text-xl">
            Detect and report scams instantly.
          </p>

          <div className="flex justify-center">
            <Link
              to="/report-scam"
              className="flex items-center gap-2 px-5 py-2 rounded-md bg-blue-600 text-white font-medium text-sm shadow-md hover:bg-blue-700 transition"
            >
              <Megaphone className="w-4 h-4" />
              Report a Scam
            </Link>
          </div>
        </div>

        {/* TOOLS */}
        <div className="grid gap-10 md:grid-cols-3">
          {/* TEXT */}
          <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition min-h-[280px] flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <ShieldCheck className="text-green-600" />
                <h2 className="font-semibold text-xl text-gray-800">
                  Text Analysis
                </h2>
              </div>
              <textarea
                rows={4}
                className="w-full border border-gray-300 p-3 rounded-md text-sm focus:ring-2 focus:ring-green-400 resize-none"
                placeholder="Paste suspicious text here..."
                value={text}
                onChange={(e) => setText(e.target.value)}
              />
            </div>
            <button
              onClick={analyzeText}
              className="mt-4 bg-green-600 hover:bg-green-700 text-white py-2 rounded-md text-sm font-medium"
            >
              Analyse Text
            </button>
          </div>

          {/* URL */}
          <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition min-h-[280px] flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Globe className="text-blue-600" />
                <h2 className="font-semibold text-xl text-gray-800">
                  URL Analysis
                </h2>
              </div>
              <input
                className="w-full border border-gray-300 p-3 rounded-md text-sm focus:ring-2 focus:ring-blue-400"
                placeholder="Paste suspicious link here..."
                value={url}
                onChange={(e) => setUrl(e.target.value)}
              />
            </div>
            <button
              onClick={analyzeURL}
              className="mt-4 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-md text-sm font-medium"
            >
              Analyse URL
            </button>
          </div>

          {/* IMAGE */}
          <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition min-h-[280px] flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <ImageIcon className="text-purple-600" />
                <h2 className="font-semibold text-xl text-gray-800">
                  Image Upload
                </h2>
              </div>
              <input
                type="file"
                className="text-sm w-full file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-purple-100 file:text-purple-700 hover:file:bg-purple-200"
                onChange={(e) => setImage(e.target.files[0])}
              />
            </div>
            <button
              onClick={uploadImage}
              className="mt-4 bg-purple-600 hover:bg-purple-700 text-white py-2 rounded-md text-sm font-medium"
            >
              Upload Image
            </button>
          </div>
        </div>

        {/* LOADING */}
        {loading && (
          <div className="flex items-center justify-center gap-2 text-sm text-gray-600 mt-6">
            <Loader2 className="animate-spin" />
            Analysing...
          </div>
        )}

        {/* RESULT */}
        {!loading && result && <div className="mt-10">{renderResult()}</div>}
      </div>
    </div>
  );
}
