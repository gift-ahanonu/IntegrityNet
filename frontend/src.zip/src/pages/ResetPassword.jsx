import { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import axios from "../utils/axios";

export default function ResetPassword() {
  const [searchParams] = useSearchParams();
  const token = searchParams.get("token");
  const [form, setForm] = useState({ password: "", confirm: "" });
  const [message, setMessage] = useState("");
  const [success, setSuccess] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (!token) {
      setMessage(" Invalid or missing token.");
    }
  }, [token]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setMessage("");
    setSuccess(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password !== form.confirm) {
      setMessage(" Passwords do not match");
      return;
    }

    try {
      await axios.post("/users/reset-password", {
        token,
        new_password: form.password,
      });
      setSuccess(true);
      setMessage("Password reset successful! Redirecting...");
      setTimeout(() => navigate("/login"), 2500);
    } catch (err) {
      setMessage(err.response?.data?.detail || " Password reset failed");
    }
  };

  return (
    <div className="min-h-screen flex text-lg">
      {/* Left side */}
      <div className="hidden lg:flex w-1/2 bg-gradient-to-tr from-blue-800 to-blue-600 text-white items-center justify-center p-16">
        <div className="max-w-lg text-center space-y-8">
          <img
            src="/favicon.png"
            alt="IntegrityNet Logo"
            className="h-32 w-32 mx-auto"
          />
          <h2 className="text-4xl font-extrabold">Secure Your Account</h2>
          <p className="text-lg text-white/80">
            Set a strong new password to protect your profile and continue using
            IntegrityNet safely.
          </p>
        </div>
      </div>

      {/* Right side - Reset Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center bg-white p-12">
        <div className="w-full max-w-xl space-y-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-800">
              Reset Your Password
            </h2>
            <p className="text-gray-500 text-base mt-1">
              Please enter your new password below.
            </p>
          </div>

          {message && (
            <div
              className={`text-center text-md font-medium ${
                success ? "text-green-600" : "text-red-600"
              }`}
            >
              {message}
            </div>
          )}

          {token && (
            <form onSubmit={handleSubmit} className="space-y-6">
              <input
                type="password"
                name="password"
                value={form.password}
                onChange={handleChange}
                placeholder="New password"
                required
                className="w-full px-5 py-3 border border-gray-300 rounded-xl text-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
              <input
                type="password"
                name="confirm"
                value={form.confirm}
                onChange={handleChange}
                placeholder="Confirm password"
                required
                className="w-full px-5 py-3 border border-gray-300 rounded-xl text-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-3 rounded-xl hover:bg-blue-700 font-semibold transition shadow"
              >
                Reset Password
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
