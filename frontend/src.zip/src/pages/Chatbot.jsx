import { useState, useEffect, useRef } from "react";
import axios from "../utils/axios";
import { MoreVertical, SendHorizonal, Plus, Loader2 } from "lucide-react";

export default function Chatbot() {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([]);
  const [sessionId, setSessionId] = useState(null);
  const [sessions, setSessions] = useState([]);
  const [guestCount, setGuestCount] = useState(
    parseInt(localStorage.getItem("chatbot_count")) || 0
  );
  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState("");
  const [menuOpenId, setMenuOpenId] = useState(null);
  const [loading, setLoading] = useState(false);
  const chatRef = useRef(null);

  const isLoggedIn = !!localStorage.getItem("token");

  useEffect(() => {
    if (isLoggedIn) fetchSessions();
  }, [isLoggedIn]);

  const scrollToBottom = () => {
    if (chatRef.current)
      chatRef.current.scrollTop = chatRef.current.scrollHeight;
  };

  const fetchSessions = async () => {
    try {
      const res = await axios.get("/chatbot/chatbot/sessions");
      setSessions(res.data.sessions || []);
    } catch {
      console.error("Failed to load sessions");
    }
  };

  const sendMessage = async () => {
    if (!input.trim()) return;

    if (!isLoggedIn && guestCount >= 5) {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content:
            "You’ve reached the limit of 5 guest messages. Please register or log in to continue using IntegrityBot.",
        },
      ]);
      return;
    }

    const userMsg = { role: "user", content: input };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const payload = { message: input };
      if (sessionId) payload.session_id = sessionId;

      const res = await axios.post("/chatbot/chatbot", payload);
      const botReply = { role: "assistant", content: res.data.response };
      setMessages((prev) => [...prev, botReply]);
      setLoading(false);

      if (!sessionId) {
        const newId = res.data.session_id;
        setSessionId(newId);
        setSessions((prev) => [{ session_id: newId, title: input }, ...prev]);
        setTimeout(fetchSessions, 1500);
      }

      if (!isLoggedIn) {
        const newCount = guestCount + 1;
        setGuestCount(newCount);
        localStorage.setItem("chatbot_count", newCount);
      }

      setTimeout(scrollToBottom, 100);
    } catch {
      setLoading(false);
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "Error getting response." },
      ]);
    }
  };

  const loadSession = async (id) => {
    try {
      const res = await axios.get(`/chatbot/chatbot/history/${id}`);
      const history = res.data.flatMap((msg) => [
        { role: "user", content: msg.message },
        { role: "assistant", content: msg.response },
      ]);
      setMessages(history);
      setSessionId(id);
      setTimeout(scrollToBottom, 100);
    } catch {
      alert("Failed to load session.");
    }
  };

  const deleteSession = async (id) => {
    if (!window.confirm("Delete this session?")) return;
    try {
      await axios.delete(`/chatbot/chatbot/delete/${id}`);
      if (sessionId === id) {
        setSessionId(null);
        setMessages([]);
      }
      fetchSessions();
    } catch {
      alert("Delete failed");
    }
  };

  const renameSession = async (id, newTitle) => {
    try {
      await axios.put(
        `/chatbot/chatbot/rename/${id}`,
        { new_title: newTitle },
        {
          headers: { "Content-Type": "application/json" },
        }
      );
      setEditingId(null);
      fetchSessions();
    } catch (err) {
      console.error("Rename failed:", err);
      alert("Rename failed");
    }
  };

  return (
    <div className="flex flex-col lg:flex-row h-screen w-full bg-gray-100 overflow-hidden">
      {isLoggedIn && (
        <aside className="w-full lg:w-72 bg-white shadow-md p-4 border-b lg:border-r lg:border-b-0 overflow-y-auto h-64 lg:h-auto">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-blue-600">Chats</h3>
            <button
              onClick={() => {
                setMessages([]);
                setSessionId(null);
              }}
              className="text-blue-600 hover:text-blue-800"
              title="Start new chat"
            >
              <Plus size={20} />
            </button>
          </div>
          <ul className="space-y-2">
            {sessions.map((session) => (
              <li
                key={session.session_id}
                className="group relative p-2 rounded-md hover:bg-gray-100"
              >
                {editingId === session.session_id ? (
                  <div className="flex items-center gap-2">
                    <input
                      value={editText}
                      onChange={(e) => setEditText(e.target.value)}
                      className="border px-2 py-1 rounded text-sm w-full"
                    />
                    <button
                      onClick={() =>
                        renameSession(session.session_id, editText)
                      }
                      className="text-green-600"
                    >
                      ✔
                    </button>
                    <button
                      onClick={() => setEditingId(null)}
                      className="text-gray-500"
                    >
                      ✕
                    </button>
                  </div>
                ) : (
                  <div className="flex justify-between items-center">
                    <span
                      onClick={() => loadSession(session.session_id)}
                      className="cursor-pointer truncate w-44"
                      title={session.title}
                    >
                      {session.title || "Untitled"}
                    </span>
                    <div className="relative">
                      <button
                        onClick={() =>
                          setMenuOpenId(
                            menuOpenId === session.session_id
                              ? null
                              : session.session_id
                          )
                        }
                      >
                        <MoreVertical className="w-4 h-4 text-gray-600 hover:text-black" />
                      </button>
                      {menuOpenId === session.session_id && (
                        <div className="absolute right-0 mt-2 bg-white border rounded shadow z-10">
                          <button
                            onClick={() => {
                              setEditingId(session.session_id);
                              setEditText(session.title);
                              setMenuOpenId(null);
                            }}
                            className="block w-full text-left px-4 py-1 hover:bg-gray-100"
                          >
                            Rename
                          </button>
                          <button
                            onClick={() => deleteSession(session.session_id)}
                            className="block w-full text-left px-4 py-1 text-red-500 hover:bg-gray-100"
                          >
                            Delete
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </li>
            ))}
          </ul>
        </aside>
      )}

      <main className="flex-1 flex flex-col">
        <header className="p-4 border-b bg-white shadow-sm">
          <h2 className="text-xl font-semibold text-gray-700">
            IntegrityBot 🤖
          </h2>
          <p className="text-sm text-gray-500">
            Helping you with scam detection and reporting
          </p>
        </header>

        <section
          ref={chatRef}
          className="flex-1 overflow-y-auto px-4 py-6 space-y-4 bg-gray-50"
        >
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex ${
                msg.role === "user" ? "justify-end" : "justify-start"
              }`}
            >
              <div
                className={`px-4 py-2 max-w-xs rounded-lg shadow ${
                  msg.role === "user" ? "bg-blue-100" : "bg-green-100"
                }`}
              >
                <p className="text-sm text-gray-800">{msg.content}</p>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex justify-start">
              <div className="px-4 py-2 max-w-xs rounded-lg shadow bg-green-100 flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-green-700" />
                <p className="text-sm text-gray-800">...</p>
              </div>
            </div>
          )}
        </section>

        {!isLoggedIn && guestCount < 5 && (
          <p className="text-center text-sm text-gray-600 mb-2">
            You have {5 - guestCount} message{5 - guestCount !== 1 && "s"} left
            before login is required.
          </p>
        )}

        <footer className="border-t bg-white p-4 flex items-center gap-3">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask IntegrityBot..."
            className="flex-1 border rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
          />
          <button
            onClick={sendMessage}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center gap-1"
          >
            <SendHorizonal size={18} /> Send
          </button>
        </footer>
      </main>
    </div>
  );
}
