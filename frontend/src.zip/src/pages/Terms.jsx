export default function Terms() {
  return (
    <div className="max-w-3xl mx-auto px-6 py-12">
      <h1 className="text-3xl font-bold mb-6">Terms of Service</h1>
      <p className="text-gray-700 mb-4">
        By using IntegrityNet, you agree to abide by the following terms and
        conditions. This platform is intended for informational and educational
        purposes only. Misuse or abuse of the services may result in account
        suspension.
      </p>
      <p className="text-gray-700 mb-4">
        We reserve the right to update these terms at any time. Continued use of
        the platform after changes are made constitutes acceptance of those
        changes.
      </p>
      <p className="text-gray-700 mb-4">
        For questions, contact integritynet.team@gmail.com.
      </p>
    </div>
  );
}
