import { useState } from 'react';
import axios from '../utils/axios';
import { useNavigate, Link } from 'react-router-dom';

export default function Register() {
  const [form, setForm] = useState({
    username: '',
    email: '',
    password: '',
    confirm: ''
  });

  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password !== form.confirm) {
      setError('Passwords do not match');
      return;
    }

    try {
      const res = await axios.post('/users/register', {
        username: form.username,
        email: form.email,
        password: form.password,
        confirm_password: form.confirm
      });
      setSuccess('🎉 Registration successful! Redirecting...');
      setTimeout(() => navigate('/login'), 1500);
    } catch (err) {
      setError(err.response?.data?.detail || 'Registration failed');
    }
  };

  return (
    <div className="min-h-screen flex text-lg">
      {/* Left Section */}
      <div className="hidden lg:flex w-1/2 bg-gradient-to-tr from-blue-700 to-blue-900 text-white items-center justify-center p-16">
        <div className="max-w-lg space-y-10">
          <img src="/favicon.png" alt="Logo" className="h-32 w-32" />
          <h2 className="text-5xl font-extrabold leading-tight">Join IntegrityNet</h2>
          <p className="text-xl opacity-90">
            Stay ahead of scams. Sign up to analyse, report and learn — all in one platform.
          </p>
          <div className="flex gap-6 text-white text-2xl">
            <i className="fab fa-facebook-f"></i>
            <i className="fab fa-x-twitter"></i>
            <i className="fab fa-instagram"></i>
            <i className="fab fa-linkedin-in"></i>
          </div>
        </div>
      </div>

      {/* Right Section */}
      <div className="w-full lg:w-1/2 flex items-center justify-center bg-white p-12">
        <div className="w-full max-w-xl space-y-8">
          <div>
            <h2 className="text-4xl font-bold text-gray-800 text-center">Create Your Account</h2>
            {error && <p className="text-red-600 text-md mt-3 text-center">{error}</p>}
            {success && <p className="text-green-600 text-md mt-3 text-center">{success}</p>}
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <input
              className="w-full border border-gray-300 rounded-xl px-5 py-3 text-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              name="username"
              placeholder="Username"
              value={form.username}
              onChange={handleChange}
              required
            />
            <input
              className="w-full border border-gray-300 rounded-xl px-5 py-3 text-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              name="email"
              type="email"
              placeholder="Email"
              value={form.email}
              onChange={handleChange}
              required
            />
            <input
              className="w-full border border-gray-300 rounded-xl px-5 py-3 text-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              name="password"
              type="password"
              placeholder="Password"
              value={form.password}
              onChange={handleChange}
              required
            />
            <input
              className="w-full border border-gray-300 rounded-xl px-5 py-3 text-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              name="confirm"
              type="password"
              placeholder="Confirm Password"
              value={form.confirm}
              onChange={handleChange}
              required
            />
            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl text-lg font-semibold transition"
            >
              Create Account
            </button>
          </form>

          <p className="text-center text-base text-gray-600">
            Already have an account?{' '}
            <Link to="/login" className="text-blue-600 hover:underline font-semibold">
              Login
            </Link>
          </p>

          <p className="text-sm text-gray-500 text-center mt-4">
            By registering you agree to our <Link to="/terms" className="underline text-blue-600">Terms of Service</Link> and <Link to="/privacy" className="underline text-blue-600">Privacy Policy</Link>.

          </p>
        </div>
      </div>
    </div>
  );
}

