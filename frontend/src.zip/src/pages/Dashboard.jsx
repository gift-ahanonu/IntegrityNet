import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Bot, PlusCircle, FileText, AlertTriangle } from "lucide-react";

const Dashboard = () => {
  const [stats, setStats] = useState({
    total: 0,
    verified: 0,
    reviewed: 0,
    pending: 0,
  });

  const [recentReports, setRecentReports] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) return;

        const headers = { Authorization: `Bearer ${token}` };

        const statsRes = await fetch("http://127.0.0.1:8000/scams/user_stats", {
          headers,
        });
        const statsData = await statsRes.json();
        setStats(statsData);

        const reportsRes = await fetch(
          "http://127.0.0.1:8000/scams/my_reports",
          { headers }
        );
        const reports = await reportsRes.json();
        console.log("📥 Reports:", reports);
        if (Array.isArray(reports)) {
          setRecentReports(reports.slice(0, 5));
        } else {
          setRecentReports([]);
        }
      } catch (err) {
        console.error("Dashboard load failed", err);
        setError("Failed to load dashboard data. Please try again.");
      }
    };

    fetchData();
  }, []);

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-xl shadow-md">
        <h2 className="text-2xl font-semibold mb-1">Welcome back 👋</h2>
        <p className="text-gray-600">Let’s keep the community scam-free!</p>
      </div>

      {error && (
        <div className="bg-red-100 border border-red-300 text-red-600 p-4 rounded-md shadow">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard
          label="Total Reports"
          value={stats.total}
          color="bg-blue-100"
        />
        <StatCard
          label="Verified"
          value={stats.verified}
          color="bg-green-100"
        />
        <StatCard
          label="Reviewed"
          value={stats.reviewed}
          color="bg-yellow-100"
        />
        <StatCard label="Pending" value={stats.pending} color="bg-red-100" />
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-md">
          <h3 className="text-xl font-semibold mb-4">Recent Reports</h3>
          {recentReports.length === 0 ? (
            <p className="text-gray-500">No recent reports found.</p>
          ) : (
            <ul className="space-y-3">
              {recentReports.map((r) => (
                <li
                  key={r.id}
                  className="flex justify-between items-center text-sm"
                >
                  <div>
                    <p className="font-medium">{r.scam_type.toUpperCase()}</p>
                    <p className="text-gray-500 truncate max-w-xs">
                      {r.content}
                    </p>
                  </div>
                  <span
                    className={`text-xs font-semibold ${
                      r.is_verified
                        ? "text-green-600"
                        : r.is_reviewed
                        ? "text-yellow-600"
                        : "text-red-600"
                    }`}
                  >
                    {r.is_verified
                      ? "Verified"
                      : r.is_reviewed
                      ? "Reviewed"
                      : "Pending"}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="bg-white p-6 rounded-xl shadow-md space-y-4">
          <h3 className="text-xl font-semibold">Quick Actions</h3>
          <div className="flex flex-col gap-3">
            <Link
              to="/report-scam"
              className="flex items-center gap-3 px-4 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700"
            >
              <PlusCircle size={18} /> Report a Scam
            </Link>
            <Link
              to="/chatbot"
              className="flex items-center gap-3 px-4 py-2 rounded-md bg-green-600 text-white hover:bg-green-700"
            >
              <Bot size={18} /> Ask IntegrityBot
            </Link>
            <Link
              to="/reports"
              className="flex items-center gap-3 px-4 py-2 rounded-md bg-gray-100 text-gray-800 hover:bg-gray-200"
            >
              <FileText size={18} /> View My Reports
            </Link>
          </div>
        </div>
      </div>

      <div className="bg-yellow-50 p-6 rounded-xl border-l-4 border-yellow-400 shadow-md flex items-start gap-4">
        <AlertTriangle className="text-yellow-500 mt-1" size={24} />
        <div>
          <h4 className="font-bold text-yellow-700">Security Tip</h4>
          <p className="text-sm text-yellow-800">
            Be cautious of emails requesting sensitive info, even if they look
            legit. Always verify the sender!
          </p>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ label, value, color }) => (
  <div className={`rounded-xl p-4 shadow-md ${color}`}>
    <p className="text-sm text-gray-600">{label}</p>
    <p className="text-2xl font-semibold">{value}</p>
  </div>
);

export default Dashboard;
